## docker  命令 

docker  

pull

ps   ps -a



命令图集  这是docker官方的。



![image-20240831085118713](docker学习记录.assets/image-20240831085118713.png)



## 概念

镜像分层





高级操作



---

## 基础操作

```sh
#找镜像 
 hub.docker.com ，或者阿里云 https://promotion.aliyun.com/ntms/act/kubernetes.html



#拉取下载镜像
docker pull nginx:1.17 或者  docker pull redis:6.24


#查看下载的镜像
docker images 

#移除镜像
docker  rmi   镜像名：tag   或者 docker  rmi   镜像ID


# 启动容器
docker run 
            容器起个名字叫nginx    指定后台运行   镜像名称                  镜像启动的一些命令     一些参数
docker run -name=nginx           -d         nginx：1.17                 ...  (非必须)             ...  (非必须) 
                           设置宿主机开机-容器自启
docker run -name=nginx  --restart=always         -d         nginx：1.17  

整体看就是 docker run    (参数)   nginx：1.17 

#查看 运行的容器，或者叫程序
docker ps 

# 所有的容器 
docker ps  -a 

# 删除停止的容器（Exit..）
docker rm 容器ID   或者  docker rm 容器名称

# 强制删除运行中的容器
docker rm -f 容器ID   或者  docker rm -f 容器名称

# 停止一个容器或者应用
docker stop 容器ID或者名称

# 再次启动停止的容器
docker start 容器ID或者名称

# 修改启动参数；修改这个容器让其在宿主机开机时自启。
docker update 容器ID或者名称 --restart-always   


#设置端口映射,这个不能通过update去修改  宿主机的88端口映射到容器的80端口
docker run -name=nginx  --restart=always         -d    -p 88:80     nginx：1.17  

```





## 进入容器

```shell
# 进入容器  可以把一个容器当成一个小的linux,进去之后就可以进入到nginx的目录了。
docker exec -it 容器ID或者名称  /bin/bash   以bash控制台方式进入

docker exec -it 容器ID或者名称  /bin/sh    以sh控制台方式进入 

# 退出  相当于从小linux中退出
exit 


#  保留配置，修改了容器里面的配置，假如要换机器，希望容器的改变仍然在。 
#  就是拿自己的容器制作了一个镜像，这个镜像只要推到云端，其他机器就可以使用自己配置的容器了

                作者      操作信息类似git   指定那个容器     搞成新的镜像，那么这些改变就在新的镜像里面了
docker commit  -a "xgz"  -m  "提交改变"    容器ID或者名称  xgzngiinx:1.1.0  




```



## 目录或者文件映射-挂载到宿主机

```sh
类似超链接，文件内容位置放在宿主机了，方便修改。

# 增加目录映射  修改宿主机内容，容器内容同时改变。 -v
# 对于频繁修改十分有作用，避免老是进入容器。根据官方文档ngixn目录是  /usr/share/nginx/html
docker run -name=nginx  --restart=always     -d    -p 88:80   -v  /root/xgz/nginx/html:/usr/share/nginx/html   nginx：1.17  
‘

#   ro  readonly 容器内不能修改 ,只能在宿主机映射的位置修改  
docker run -name=nginx  --restart=always     -d    -p 88:80   -v  /root/xgz/nginx/html:/usr/share/nginx/html:ro   nginx：1.17  

#   rw read write 容器内可修改 
docker run -name=nginx  --restart=always     -d    -p 88:80   -v  /root/xgz/nginx/html:/usr/share/nginx/html:rw   nginx：1.17 

```



## 镜像保存

```sh
# 镜像保存  打包成一个tar包 ，将镜像打包成物理镜像
             打成tar包   镜像名称
docker save -o abc.tar  xgzngiinx:1.1.0  
这个包可以到处传送，然后再其他机器运行

# 在别的机器上将镜像加载出来,这里就不是解压啥了!!.然后使用docker images 就可以查看到镜像已经存在这个机器了
docker load -r abc.tar
```



## 推送仓库

```sh
# 只需要两个命令  new-repo 仓库名称
docker tag local-image:tagname  new-repo:tagname
docker push new-repo:tagname

docker tag  xgzngiinx:1.1.0     192.168.93.6:5000/xgzngiinx:1.1.0   名字不改
docker push 192.168.93.6:5000/xgzngiinx:1.1.0

# 要先登录,只需要登录一次。不登出的，后面一直可以推
docker login

# 退出
docker logout

```



## 常用命令-日志-文件挂载映射-复制文件

```sh
#查看日志
docker logs  容器iD或者名称


# 挂载配置文件  类推，redis,mysql都是一样的道理，都可以把 目录给映射挂载到宿主机上。
#   宿主机上的文件必须提前创建，目录就没必要了。因为docker会以目方式去创建，所以目录无所谓，文件必须提前创建。因为：docker创建的nginx.conf是个目录。
docker run -name=nginx  --restart=always     -d    -p 88:80   -v  /root/xgz/nginx/html:/usr/share/nginx/html:rw
  -v /root/xgz/nginx/conf/nginx.conf:/etc/nginx/nginx.conf  nginx：1.17 
  
  
  
# docker里面的文件复制到宿主机,反向复制也是可以的   相当于一个大linux和一个小linux进行同信
docker cp 容器ID:/etc/nginx/nginx.conf  /root/xgz/nginx/conf/nginx.conf
docker cp   /root/xgz/nginx/conf/nginx.conf  容器ID:/etc/nginx/nginx.conf 
```



## Dcokfile

```Dcoker
# 基础镜像
FROM  openjdk:8-jdk-slim

LABEL maintainer=xgz

COPY target/*.jar  /app.jar

ENTRYPOINT ["java","-jar","/app.jar"]


最后把jar包和 ，dockerfile上传至linux一个目录，这两个在同一个文件夹下。

构建镜像  

构建镜像         镜像名称          这个点不能少（指当前目录）          指定文件
docker build -t java-demo:1.0.0  .                            -f Dockerfile


查看运行日志
docker ps 拿到  容器ID或者容器名称

docker logs 容器ID或者容器名称 

docker logs 容器ID或者容器名称  -f  滚动更新查看

```

