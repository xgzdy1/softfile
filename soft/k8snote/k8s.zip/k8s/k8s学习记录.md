## 1.kubectl命令

各资源对象命令，常见资源对象：pods,nodes,deployment,service,namespace,replicaset,daemonset,statefulset，label

 kubectl get deploy --all-namespaces

 kubectl get po --all-namespaces

查看deploy

 kubectl describe deploy  nfs-subdir-external-provisioner -n nfs-provisioner

### pods

```sh
#查看pod
kubectl get pod
kubectl get pods #与上面等效

# 查看pod,加上指定名称
kubectl get pod nnginx-6799fc88d8-gs4wt

# 查看pod,加上指定名称，以yaml方式查看
kubectl get pod nnginx-6799fc88d8-gs4wt


程序运行在容器里，容器运行在pod里，pod是k8s管理的最小级别的单元
集群中各个组件都是以pod方式在运行的
# 查看集群组件列表
kubectl get pod -n kube-system

k8s没有单独提供运行pod的命令，而是以pod控制器的方式控制的。 这个需要再次验证下。可能存量原因导致我没有pod控制器重启pod
# 在dev空间下创建一个nginx类型的pod并运行，这里我的pod名称应该是nginx--de ,结果名字就叫pod
kubectl run nginx --image=nginx:latest --port=80 --namespace dev

# 查看pod详情
kubectl describe pod nginx -n dev

#获取podIP
kubectl get pods -n dev -o wide


# 删除指定pod
kubectl delete pod nginx -n dev
```

配置方式 创建pod

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: nginx
  namespace: dev
spec:
  containers:
  - image: nginx:latest
    name: pod
    ports:
    - name: nginx-port
      containerPort: 80
      protocol: TCP

```

kubectl create -f pod-nginx.yaml 

删除

kubectl delete -f pod-nginx.yaml 



关于pod

pause是pod内的一个根容器，可以实现pod内容器之间通信，也可以评估pod内部容器的状态。





### deployment

pod控制器中一种

```sh
#创建一个nginx无状态服务
kubectl create deployment nginx --image=nginx:1.14-alpine

#暴露nginx端口，网络访问访问是nodeport,其他类型有loadblance、exteralIP
kubectl expose deploy nginx --port=80 --target-port=80  --type=NodePort

删除pod的pod控制器
kubectl delete deploy nginx -n dev  
#首先就是要创建deployment控制器，才能实现删除pod之后，自动新建一个。我这里没有新建pod控制器，删除pod就直接删除了。


#这个方式  创建多副本 在1.18就不行了，
kubectl run nginx --image=nginx:latest --port=80 --replicas=3 -n dev

# 1.21
kubectl version

# 改为如下
kubectl create deploy nginx-deploy -n dev
kubectl scale delpoyment nginx-deploy --replicas=3 -n dev  #  这个命令也没成功，下面配置文件方式成功了，3个副本
```



配置方式

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: deploy-nginx
  namespace: dev
spec:
  replicas: 3
  selector:
    matchLabels:
      run: nginx
  template:
    metadata:
      labels:
        run: nginx
    spec:
      containers:
      - image: nginx:latest
        name: nginx
        ports:
        - containerPort: 80
          protocol: TCP

```

kubectl create -f deploy-nginx.yaml

podIP会随着pod重建而更新，所以k8s的service设计时，就不存在这个问题了



### service

```sh
#查看pod对应的service
kubectl get pod,svc
```



创建service

```yaml
apiVersion: v1
kind: Service
metadata:
  name: service-nodeport
  namespace: dev
spec:
  selector:
    app: nginx-pod
  type: NodePort # service类型
  ports:
  - port: 80
    nodePort: 30002
    targetPort: 80
```

根据配置创建资源对象

kubectl create -f service-nodeport.yaml 

查看service

kubectl get svc -o wide -n dev



```sh
## 暴露service,使集群内部可以访问service
kubectl expose deploy deploy-nginx --name=svc-nginx1 --type=ClusterIP --port=80 --target-port=80 -n dev

# 查看service，这个clusterIP就是serviceIP,类型是Cluster，还是external/nodeport类型
 kubectl get svc svc-nginx1 -n dev -o wide
 
NAME         TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)   AGE     SELECTOR
svc-nginx1   ClusterIP   10.10.131.111   <none>        80/TCP    2m35s   run=nginx

#在工作节点 访问这个service，可以看到nginx的输出
curl 10.10.131.111:80  #CLUSTER-IP:80

## 创建集群外部可访问serviceIP,也就是NodePort类型
kubectl expose deploy deploy-nginx --name=svc-nginx2 --type=NodePort --port=80 --target-port=80 -n dev

#查看pod
kubectl get svc svc-nginx2 -n dev -o wide
NAME         TYPE       CLUSTER-IP      EXTERNAL-IP   PORT(S)        AGE   SELECTOR
svc-nginx2   NodePort   10.10.116.111   <none>        80:31009/TCP   48s   run=nginx

#在节点浏览器访问
192.168.93.7:31009 #节点IP:31009

#删除service
 kubectl delete svc svc-nginx1 -n dev

```

配置方式创建service

```yaml
apiVersion: v1
kind: Service
metadata:
  name: svc-nginx
  namespace: dev
spec:
  clusterIP: 10.10.116.110 #固定svc的内网IP
  ports:
  - port: 80
    protocol: TCP
    targetPort: 80
  selector:
    run: nginx

```

kubectl create -f svc-nginx.yaml 创建 

kubectl delete -f svc-nginx.yaml 删除





### ns

```sh
#名称空间： 名称空间和service一样，主要作用就是资源隔离，层级范围不一样而已
# 创建名称空间，dev
kubectl create namespace dev
kubectl create ns dev

# 查看名称空间
kubectl get ns

# 在dev空间下创建一个nginx类型的pod并运行，这里我的pod名称应该是nginx--de ,结果名字就叫pod
kubectl run pod --image=nginx:latest -n dev

#查看dev空间下的pod
kubectl get pod -n dev

#删除pod,刚好我这里pod名称就叫pod,一般名称都包含容器相关的
kubectl delete pod pod -n dev

# 删除名称空间
kubectl delete ns dev

# 以yaml方式查看名称空间，yaml/json/wide
kubectl get ns dev -o yaml

#查看名称空间详情
kubectl describe ns dev


```

配置方式创建名称空间-

创建ns-dev.yaml

kubectl create -f ns-dev.yaml

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: dev
```

删除

kubectl delete -f ns-dev.yaml



rs



### nodes

```sh
#查看节点信息
kubectl get nodes
```





daemonset



statefulset





所有资源列表，

k8s里面所有内容都抽象为资源，命令查看方式如下

```sh
# 查看k8s所有资源
kubectl api-resources

kubectl --help # 命令帮助

#常见命令
create
edit
get
patch
delete
explain
run
expose
describe
logs
attach
exec
cp
rollout
scale
autoscale
apply
cluster-info
version
```





### label

作用是给资源打上标签，key\value形式

定义标签、

给资源打标签，有两种基于等式的和基于集合的。name=nginx,  name in (master,worker)

标签选择的时候，可以有多个，逗号分隔。通过多组标签去找出具体的资源。

命令方式

```sh
# 给名为nginx的pod打上version=1.0的标签
kubectl label pod nginx  version=1.0 -n dev

# 查看pod的标签
 kubectl get pod nginx -n dev -o wide --show-labels
NAME    READY   STATUS    RESTARTS   AGE   IP             NODE      NOMINATED NODE   READINESS GATES   LABELS
nginx   1/1     Running   0          23h   10.18.189.70   worker2   <none>           <none>            version=1.0

#更新资源标签
kubectl label pod nginx  version=2.0 -n dev --overwrite

#通过标签去筛选资源;这里是找到label为version=2.0的pod
kubectl get pod  -n dev -l version=2.0 --show-labels

# 通过标签去筛选资源;这里是找到label为version!=2.0的pod
kubectl get pod  -n dev -l version!=2.0 --show-labels

#通过in的方式去筛选资源 
kubectl get pod  -n dev -l 'version in (2.0)' --show-labels
kubectl get pod  -n dev -l 'version in (1.0)' --show-labels
kubectl get pod  -n dev -l 'version in (1.0，2.0)' --show-labels
kubectl get pod  -n dev -l 'version notin (1.0,2.0)' --show-labels

#删除标签，key-   一个key和一个减号
kubectl label pod  nginx -n dev version-

#查看标签
kubectl get pod nginx -n dev -o wide --show-labels


```



配置方式

编辑pod-nginx.yaml

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: nginx
  namespace: dev
  labels:
    version: "3.0"
    env: "test"
spec:
  containers:
  - image: nginx:latest
    name: pod
    ports:
    - name: nginx-port
      containerPort: 80
      protocol: TCP
```

删除之前的pod

kubectl delete pod nginx -n dev

```sh
#新建pod,
kubectl apply -f pod-nginx.yaml 

#查看pod，看到标签已经被打上了
kubectl get pod -n dev -o wide --show-labels

#筛选出打标签的pod
kubectl get pod -n dev -l env=test 
kubectl get pod -n dev -l env=test,version=3.0   多个标签去筛选
```





容器，也就是docker,这里专指docker







## 2.docker命令







## 3.3种创建 资源对象的方式

命令式对象配置文件，使用命令和配置文件配合操作k8s资源

创建一个nginxpod-yaml

下面是创建了名称空间和pod

```yaml
apiVersion: v1
kind: Namespace
metadata: 
  name: dev


---

apiVersion: v1
kind: Pod
metadata:
  name: nginxpod
  namespace: dev
spec:
  containers:
  - name: nginx-containers
    image: nginx:latest
```



第一种：创建资源对象--命令式对象配置，需要配置文件

```sh
kubectl create -f nginxpod.yaml

#查看资源对象,可以看到有两个，一个是名称空间，一个是pod
kubectl get -f nginxpod.yaml

#删除资源对象
kubectl delete -f nginxpod.yaml 
```

**到目前为止，已经知道两种方式去创建k8s的资源对象了，一种是kubectl run  ..镜像名称（第二种），另一种是kubectl create ..yaml**

run这种是命令式对象管理（第二种），这种直接使用命令

最后一种方式去创建资源资源对象，一共就三种，这是最后一种了

创建资源对象--声明式对象配置（第三种），需要配置文件

```sh
# 创建资源对象
kubectl apply -f nginxpod.yaml 
```





配置文件解释、

```sh
# 可以查看每个配置是什么意思
kubectl explain pod.spec  
```



对于控制器，官方推荐是 delployment->replicaset->pod 这样才是合理

对于无状态的（b不依赖固定Ip等的）资源调度，更合理的是：deploy控制自动调度、replicaset控制扩缩容，pod执行容器运行基本业务







配置kubectl在节点上运行

```json
学习Kubernetes（K8s）时，实践是非常重要的环节，通过实践可以加深对K8s概念的理解，并熟悉其操作。以下是一些可以自己实践的步骤和项目，以便于更好地理解和掌握K8s：
一、搭建K8s环境
本地环境搭建：
使用Minikube、Kind等工具在本地机器上搭建一个单节点的K8s集群。这些工具可以简化安装过程，让你快速拥有一个可用的K8s环境。
安装Docker（如果Minikube或Kind需要），并确保Docker服务正常运行。
云平台环境搭建：
如果条件允许，也可以在云平台（如AWS、Azure、GCP等）上搭建K8s集群。云平台通常提供了更丰富的资源和更灵活的配置选项。


二、基础操作实践
部署简单应用：
创建一个简单的Dockerfile，例如基于Nginx或Hello World应用的Dockerfile。
使用Docker构建镜像，并将其推送到Docker Hub或其他容器镜像仓库。
在K8s集群中部署这个应用，包括创建Deployment、Service等资源。
查看和管理资源：

-------------------
使用kubectl命令行工具查看和管理K8s集群中的资源，如Pods、Deployments、Services等。
熟悉kubectl的各种命令和选项，了解如何通过YAML文件定义和管理资源。



----------------
三、进阶操作实践
配置和管理存储：
学习如何在K8s中配置和管理存储，包括使用PersistentVolumes和PersistentVolumeClaims来管理持久化存储。
可以尝试部署一个需要存储支持的应用，如数据库或文件存储服务。
网络和服务发现：
了解K8s中的网络模型和服务发现机制。
尝试配置Ingress资源来实现外部访问，或使用Service Mesh（如Istio）来管理复杂的网络和服务间通信。
自动化和扩展：
学习如何使用Horizontal Pod Autoscaler（HPA）根据CPU或内存使用率自动扩展Pod的数量。
了解Prometheus、Grafana等监控工具，并尝试将它们集成到K8s集群中以实现监控和告警。
四、实际项目实践
部署复杂应用：
选择一个复杂的应用（如WordPress+MySQL、微服务架构的应用等），并在K8s集群中部署它。
了解如何配置和管理应用中的各个组件，包括数据库、前端服务、后端服务等。
故障排查和调试：
在实践过程中，可能会遇到各种问题和故障。学习如何排查和调试这些问题，了解K8s的日志和事件系统。
可以使用Kubectl describe、logs等命令来查看Pod和容器的状态和日志信息。
五、参与社区和分享经验
加入社区：
加入K8s的官方社区或相关论坛，与其他学习者和专家交流经验、解决问题。
参与社区的讨论和活动，了解K8s的最新动态和最佳实践。
分享经验：
在博客、GitHub、技术论坛等平台上分享你的学习经验和项目实践。这不仅可以帮助他人，也可以让你在分享过程中进一步巩固自己的知识。
通过以上实践步骤和项目，你可以逐步加深对K8s的理解和掌握，提高自己的实践能力和解决问题的能力。
```



## 4.pod一些属性功能

kubectl explain pod  解释pod

kubectl explain pod.spec.containers 解释  containers



containers 中的配置

--拉取策略

基础yaml,vim pod-base.yaml

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: pod-base
  namespace: dev
  labels:
    user: heima
spec:
  containers:
  - name: nginx
    image: nginx:1.17.1
  - name: busybox
    image: busybox:1.30

```

kubectl apply -f  pod-base.yaml

查看pod

```sh
kubectl get pod -n dev

kubectl get pod pod-base -n dev

NAME       READY   STATUS             RESTARTS   AGE
pod-base   1/2     CrashLoopBackOff   3          2m31s

pod里面有两个容器，一个有问题，一个在重启

#查看详情
kubectl describe pod pod-base -n dev


```



镜像拉取

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: pod-imagepullpolicy
  namespace: dev
spec:
  container:
  - name: nginx
    nginx: nginx:1.17.1
    imagePullPolicy: Never
  - name: busybox
    image: busybox:1.30

```

 kubectl create -f pod-imagepullpolicy.yaml

```sh
kubectl describe pod pod-imagepullpolicy -n dev

观察到详情中，有nginx 拉取策略为Never的策略

[root@master ~]# kubectl get pod -n dev
NAME                            READY   STATUS             RESTARTS   AGE
deploy-nginx-5bdb994596-dprsv   1/1     Running            0          24h
deploy-nginx-5bdb994596-mzp46   1/1     Running            0          24h
deploy-nginx-5bdb994596-xjbcd   1/1     Running            0          24h
nginx                           1/1     Running            0          64m
pod-base                        1/2     CrashLoopBackOff   7          14m  # busybox没起来，nginx采用默认拉取策略，指定tag1.17.1.只有nginx起来了
pod-imagepullpolicy             0/2     CrashLoopBackOff   3          99s  # busy没起来，nginx指定本地寻找镜像（Never），本地没有。这里两个都没起来

```



拉取策略

```
Always：总是从远程仓库拉取镜像（一直远程下载）
IfNotPresent：本地有则使用本地镜像，本地没有则从远程仓库拉取镜像（本地有就本地 本地没远程下载）
Never：只使用本地镜像，从不去远程仓库拉取，本地没有就报错 （一直使用本地）

默认值说明：
如果镜像tag为具体版本号， 默认策略是：IfNotPresent
如果镜像tag为：latest（最终版本） ，默认策略是always
```



--启动命令

上面busybox没有启动成功，原因如下

```
在前面的案例中，一直有一个问题没有解决，就是的busybox容器一直没有成功运行，那么到底是什么原因导致这个容器的故障呢？

原来busybox并不是一个程序，而是类似于一个工具类的集合，kubernetes集群启动管理后，它会自动关闭。解决方法就是让其一直在运行，这就用到了command配置。
```

创建文件 pod-command.yaml

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: pod-command
  namespace: dev
spec:
  containers:
  - name: nginx
    image: nginx:1.17.1
  - name: busybox
    image: busybox:1.30
    command: ["/bin/sh","-c","touch /tmp/hello.txt;while true;do /bin/echo $(date +%T) >> /tmp/hello.txt; sleep 3; done;"]

```

```
command，用于在pod中的容器初始化完毕之后运行一个命令。
```

```
稍微解释下上面命令的意思：

“/bin/sh”,“-c”, 使用sh执行命令
touch /tmp/hello.txt; 创建一个/tmp/hello.txt 文件
while true;do /bin/echo $(date +%T) >> /tmp/hello.txt; sleep 3; done; 每隔3秒向文件中写入当前时间
```

运行pod

```sh
kubectl create -f pod-command.yaml 

查看两个pod都已正常
[root@master ~]# kubectl get pod pod-command -n dev
NAME          READY   STATUS    RESTARTS   AGE
pod-command   2/2     Running   0          33s

#进入busybox容器内部查看
kubectl exec pod-command -n dev -it -c busybox /bin/sh # 进入pod: exec pod-command   进入容器： -it -c busybox /bin/sh

kubectl exec [POD] [COMMAND] is DEPRECATED and will be removed in a future version. Use kubectl exec [POD] -- [COMMAND] instead.
/ # tail -f /tmp/hello.txt 
00:38:33
00:38:36
00:38:39
00:38:42
00:38:45
00:38:48
00:38:51
00:38:54
00:38:57
00:39:00
00:39:03

```

一些笔记资料

```
特别说明：
    通过上面发现command已经可以完成启动命令和传递参数的功能，为什么这里还要提供一个args选项，用于传递参数呢?这其实跟docker有点关系，kubernetes中的command、args两项其实是实现覆盖Dockerfile中ENTRYPOINT的功能。
 1 如果command和args均没有写，那么用Dockerfile的配置。
 2 如果command写了，但args没有写，那么Dockerfile默认的配置会被忽略，执行输入的command
 3 如果command没写，但args写了，那么Dockerfile中配置的ENTRYPOINT的命令会被执行，使用当前args的参数
 4 如果command和args都写了，那么Dockerfile的配置被忽略，执行command并追加上args参数
```



删除之前的镜像拉取创建的pod,

 kubectl delete pod pod-base pod-imagepullpolicy  -n dev

--环境变量

创建文件

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: pod-env
  namespace: dev
spec:
  containers:
  - name: busybox
    image: busybox:1.30
    command: ["/bin/sh","-c","while true;do /bin/echo $(date +%T);sleep 60; done;"]
    env: #环境变量列表
    - name: "username"
      value: "admin"
    - name: "password"
      value: "123456"

```



创建资源、进入pod中的容器，查看环境变量

```sh
kubectl create -f pod-env.yaml

kubectl exec pod-env -n dev -c busybox -it /bin/sh

echo $username

#退出
exit

```



--端口设置

```sh
# 解释容器的端口
kubectl explain pod.spec.containers.ports
KIND:     Pod
VERSION:  v1
RESOURCE: ports <[]Object>
FIELDS:
   name         <string>  # 端口名称，如果指定，必须保证name在pod中是唯一的		
   containerPort<integer> # 容器要监听的端口(0<x<65536)
   hostPort     <integer> # 容器要在主机上公开的端口，如果设置，主机上只能运行容器的一个副本(一般省略) 
   hostIP       <string>  # 要将外部端口绑定到的主机IP(一般省略)
   protocol     <string>  # 端口协议。必须是UDP、TCP或SCTP。默认为“TCP”。


```

pod-ports.yaml创建

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: pod-ports
  namespace: dev
spec:
  containers:
  - name: nginx
    image: nginx:1.17.1
    ports:
    - name: nginx-port
      containerPort: 80
      protocol: TCP
```



yaml形式查看pod

```sh
kubectl get pod pod-ports -n dev -o yaml

```



--资源配额

vim pod-resources.yaml

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: pod-resources
  namespace: dev
spec:
  containers:
  - name: nginx
    image: nginx:1.17.1
    resources: # 资源配额
      limits: #资源限制
        cpu: "2" #CPU限制，单位是core数
        memory: "10Gi" # 内存限制
      requests: #请求限制
        cpu: "1" # cpu限制，单位core数
        memory: "10Mi" #内存限制

```

```sh
kubectl create -f pod-resources.yaml
#查看正常运行
kubectl get pod pod-resources -n dev
NAME            READY   STATUS    RESTARTS   AGE
pod-resources   1/1     Running   0          94s

停止pod  requests内存改为10Gi，启动失败，查看详情
kubectl delete -f pod-resources.yaml 
  requests: #请求限制
        cpu: "1" # cpu限制，单位core数
        memory: "1GMi" #内存限制
kubectl create -f pod-resources.yaml

[root@master ~]# kubectl get pod pod-resources -n dev -o wide
NAME            READY   STATUS    RESTARTS   AGE   IP       NODE     NOMINATED NODE   READINESS GATES
pod-resources   0/1     Pending   0          62s   <none>   <none>   <none>           <none>

kubectl describe pod pod-resource -n dev 

#事件event那里出问题
 Warning  FailedScheduling  108s  default-scheduler  0/3 nodes are available: 1 node(s) had taint {node-role.kubernetes.io/master: }, that the pod didn't tolerate, 2 Insufficient memory.
  Warning  FailedScheduling  106s  default-scheduler  0/3 nodes are available: 1 node(s) had taint {node-role.kubernetes.io/master: }, that the pod didn't tolerate, 2 Insufficient memory.

```



5.pod生命周期

一些资料

```
pod的创建过程

用户通过kubectl或其他api客户端提交需要创建的pod信息给apiServer

apiServer开始生成pod对象的信息，并将信息存入etcd，然后返回确认信息至客户端

apiServer开始反映etcd中的pod对象的变化，其它组件使用watch机制来跟踪检查apiServer上的变动

scheduler发现有新的pod对象要创建，开始为Pod分配主机并将结果信息更新至apiServer

node节点上的kubelet发现有pod调度过来，尝试调用docker启动容器，并将结果回送至apiServer

apiServer将接收到的pod状态信息存入etcd中
```

![img](k8s学习记录.assets/202307031707429.png)





销毁/结束过程

探针-三种

重启策略（）这个是pod的不是容器的

pod调度，主要就是亲和性和标签的使用搭配：定向调度、亲和性调度

污点和容忍



## 5.控制器-更进一步使用

```
在kubernetes中，有很多类型的pod控制器，每种都有自己的适合的场景，常见的有下面这些：

ReplicationController：比较原始的pod控制器，已经被废弃，由ReplicaSet替代
ReplicaSet：保证副本数量一直维持在期望值，并支持pod数量扩缩容，镜像版本升级
Deployment：通过控制ReplicaSet来控制Pod，并支持滚动升级、回退版本
Horizontal Pod Autoscaler：可以根据集群负载自动水平调整Pod的数量，实现削峰填谷
DaemonSet：在集群中的指定Node上运行且仅运行一个副本，一般用于守护进程类的任务
Job：它创建出来的pod只要完成任务就立即退出，不需要重启或重建，用于执行一次性任务
Cronjob：它创建的Pod负责周期性任务控制，不需要持续后台运行
StatefulSet：管理有状态应用
```



--rs



ReplicaSet清单文件

```yaml
apiVersion: apps/v1 # 版本号
kind: ReplicaSet # 类型       
metadata: # 元数据
  name: # rs名称 
  namespace: # 所属命名空间 
  labels: #标签
    controller: rs
spec: # 详情描述
  replicas: 3 # 副本数量
  selector: # 选择器，通过它指定该控制器管理哪些pod
    matchLabels:      # Labels匹配规则
      app: nginx-pod
    matchExpressions: # Expressions匹配规则
      - {key: app, operator: In, values: [nginx-pod]}
  template: # 模板，当副本数量不足时，会根据下面的模板创建pod副本
    metadata:
      labels:
        app: nginx-pod
    spec:
      containers:
      - name: nginx
        image: nginx:1.17.1
        ports:
        - containerPort: 80
```

```
replicas：指定副本数量，其实就是当前rs创建出来的pod的数量，默认为1

selector：选择器，它的作用是建立pod控制器和pod之间的关联关系，采用的Label Selector机制

在pod模板上定义label，在控制器上定义选择器，就可以表明当前控制器能管理哪些pod了

template：模板，就是当前控制器创建pod所使用的模板板，里面其实就是前一章学过的pod的定义
```



ReplicaSet -资源文件

pc-replicaset.yaml

```yaml
apiVersion: apps/v1
kind: ReplicaSet
metadata:
  name: pc-replicaset
  namespace: dev
spec:
  replicas: 3
  selector:
    matchLabels:
      app: nginx-pod
  template:
    metadata:
      labels:
        app: nginx-pod
    spec:
      containers:
      - name: nginx

```

创建rs

```sh
kubectl create -f pc-replicaset.yaml


# DESIRED:期望副本数量  
# CURRENT:当前副本数量  
# READY:已经准备好提供服务的副本数量
#查看rs
[root@master podcontroller]# kubectl get rs pc-replicaset -n dev -o wide
NAME            DESIRED   CURRENT   READY   AGE   CONTAINERS   IMAGES         SELECTOR
pc-replicaset   3         3         3       22s   nginx        nginx:1.17.1   app=nginx-pod

#查看pod
# 查看当前控制器创建出来的pod
# 这里发现控制器创建出来的pod的名称是在控制器名称后面拼接了-xxxxx随机码
[root@master podcontroller]# kubectl get pod -n dev
NAME                            READY   STATUS    RESTARTS   AGE
pc-replicaset-hrkt7             1/1     Running   0          88s
pc-replicaset-p8pcs             1/1     Running   0          88s
pc-replicaset-xkjnc             1/1     Running   0          88s


#修改rs的pod副本数为6
kubectl edit rs pc-replicaset -n dev
将replicas:3 改为 replicas:6

#查看pod
[root@master podcontroller]# kubectl get pods -n dev
NAME                  READY   STATUS    RESTARTS   AGE
pc-replicaset-hrkt7   1/1     Running   0          18m
pc-replicaset-mz74q   1/1     Running   0          66s
pc-replicaset-p8pcs   1/1     Running   0          18m
pc-replicaset-q8x7q   1/1     Running   0          66s
pc-replicaset-qchlx   1/1     Running   0          66s
pc-replicaset-xkjnc   1/1     Running   0          18m


#通过命令修改，副本数改为2
kubectl scale rs pc-replicaset --replicas=2 -n dev

[root@master podcontroller]# kubectl get pods -n dev
NAME                  READY   STATUS    RESTARTS   AGE
pc-replicaset-hrkt7   1/1     Running   0          19m
pc-replicaset-xkjnc   1/1     Running   0          19m

```

---镜像升级

```sh
将nginx的镜像image版本升级1.17.2

# 查看，惊喜那个版本已变为1.17.2
[root@master podcontroller]# kubectl get rs pc-replicaset -n dev -o wide
NAME            DESIRED   CURRENT   READY   AGE   CONTAINERS   IMAGES         SELECTOR
pc-replicaset   2         2         2       24m   nginx        nginx:1.17.2   app=nginx-pod

# 删除rs
kubectl get rs pc-replicaset -n dev -o wide

# 通过yaml方式删除 （推荐）
kubectl delete -f pc-replicaset.yaml

```



-- Deployment

```
为了更好的解决服务编排的问题，kubernetes在V1.2版本开始，引入了Deployment控制器。值得一提的是，这种控制器并不直接管理pod，而是通过管理ReplicaSet来简介管理Pod，即：Deployment管理ReplicaSet，ReplicaSet管理Pod。所以Deployment比ReplicaSet功能更加强大。
```

```
Deployment主要功能有下面几个：

支持ReplicaSet的所有功能
支持发布的停止、继续
支持滚动升级和回滚版本
```

清单文件

```yaml
apiVersion: apps/v1 # 版本号
kind: Deployment # 类型       
metadata: # 元数据
  name: # rs名称 
  namespace: # 所属命名空间 
  labels: #标签
    controller: deploy
spec: # 详情描述
  replicas: 3 # 副本数量
  revisionHistoryLimit: 3 # 保留历史版本
  paused: false # 暂停部署，默认是false
  progressDeadlineSeconds: 600 # 部署超时时间（s），默认是600
  strategy: # 策略
    type: RollingUpdate # 滚动更新策略
    rollingUpdate: # 滚动更新
      max违规词汇: 30% # 最大额外可以存在的副本数，可以为百分比，也可以为整数
      maxUnavailable: 30% # 最大不可用状态的 Pod 的最大值，可以为百分比，也可以为整数
  selector: # 选择器，通过它指定该控制器管理哪些pod
    matchLabels:      # Labels匹配规则
      app: nginx-pod
    matchExpressions: # Expressions匹配规则
      - {key: app, operator: In, values: [nginx-pod]}
  template: # 模板，当副本数量不足时，会根据下面的模板创建pod副本
    metadata:
      labels:
        app: nginx-pod
    spec:
      containers:
      - name: nginx
        image: nginx:1.17.1
        ports:
        - containerPort: 80
```



创建pc-deployment.yaml

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: pc-deployment
  namespace: dev
spec:
  replicas: 3
  selector:
    matchLabels:
      app: nginx-pod
  template:
    metadata:
      labels:
        app: nginx-pod
    spec:
      containers:
      - name: nginx
        image: nginx:1.17.1

```

创建deployment类型控制器

```sh
#创建deployment类型控制器的资源
kubectl create -f pc-deployment.yaml --record=true

# UP-TO-DATE 最新版本的pod的数量
# AVAILABLE  当前可用的pod的数量
#查看pod
kubectl get deploy pc-deployment -n dev
kubectl get deploy -n dev
NAME            READY   UP-TO-DATE   AVAILABLE   AGE
pc-deployment   3/3     3            3           49s

[root@master podcontroller]# kubectl get deploy -n dev -o wide
NAME            READY   UP-TO-DATE   AVAILABLE   AGE   CONTAINERS   IMAGES         SELECTOR
pc-deployment   3/3     3            3           81s   nginx        nginx:1.17.1   app=nginx-pod

#查看pod
[root@master podcontroller]# kubectl get pods -n dev
NAME                             READY   STATUS    RESTARTS   AGE
pc-deployment-5d9c9b97bb-87ls5   1/1     Running   0          2m34s
pc-deployment-5d9c9b97bb-v24jm   1/1     Running   0          2m34s
pc-deployment-5d9c9b97bb-vt9fl   1/1     Running   0          2m34s

```

---扩缩容

```sh
# 增加到5个
kubectl scale deploy pc-deployment --replicas=5 -n dev

#查看
[root@master podcontroller]# kubectl get pods -n dev
NAME                             READY   STATUS    RESTARTS   AGE
pc-deployment-5d9c9b97bb-7hm9f   1/1     Running   0          24s
pc-deployment-5d9c9b97bb-87ls5   1/1     Running   0          4m20s
pc-deployment-5d9c9b97bb-v24jm   1/1     Running   0          4m20s
pc-deployment-5d9c9b97bb-vt9fl   1/1     Running   0          4m20s
pc-deployment-5d9c9b97bb-wwwgx   1/1     Running   0          24s
[root@master podcontroller]# kubectl get deploy pc-deployment -n dev
NAME            READY   UP-TO-DATE   AVAILABLE   AGE
pc-deployment   5/5     5            5           4m57s

#通过编辑pc-deployment 方式副本数改为2, replicas: 5 >>  replicas: 2
kubectl get deploy pc-deployment -n dev  #这里没有.yaml结尾

[root@master podcontroller]# kubectl get deploy pc-deployment -n dev
NAME            READY   UP-TO-DATE   AVAILABLE   AGE
pc-deployment   2/2     2            2           7m35s

#查看对应的pod
[root@master podcontroller]# kubectl get pods -n dev
NAME                             READY   STATUS    RESTARTS   AGE
pc-deployment-5d9c9b97bb-vt9fl   1/1     Running   0          8m20s
pc-deployment-5d9c9b97bb-wwwgx   1/1     Running   0          4m24s

```

---镜像更新

```
deployment支持两种更新策略:重建更新和滚动更新,可以通过strategy指定策略类型,支持两个属性:

strategy：指定新的Pod替换旧的Pod的策略， 支持两个属性：
  type：指定策略类型，支持两种策略
    Recreate：在创建出新的Pod之前会先杀掉所有已存在的Pod
    RollingUpdate：滚动更新，就是杀死一部分，就启动一部分，在更新过程中，存在两个版本Pod
  rollingUpdate：当type为RollingUpdate时生效，用于为RollingUpdate设置参数，支持两个属性：
    maxUnavailable：用来指定在升级过程中不可用Pod的最大数量，默认为25%。
    max违规词汇： 用来指定在升级过程中可以超过期望的Pod的最大数量，默认为25%。
```



```yaml
重建更新

编辑pc-deployment.yaml,在spec节点下添加更新策略
spec:
  strategy: # 策略
    type: Recreate # 重建更新
```



开始更新镜像

```sh
kubectl set image deployment pc-deployment nginx=nginx:1.17.2 -n dev

# 观察升级过程
[root@master podcontroller]# kubectl get po -n dev  -w
NAME                             READY   STATUS              RESTARTS   AGE
pc-deployment-5d9c9b97bb-vt9fl   1/1     Running             0          14m
pc-deployment-5d9c9b97bb-wwwgx   1/1     Running             0          10m
pc-deployment-7c7477c7ff-sv9h7   0/1     ContainerCreating   0          92s
pc-deployment-7c7477c7ff-sv9h7   1/1     Running             0          2m19s  第一个
pc-deployment-5d9c9b97bb-wwwgx   1/1     Terminating         0          11m
pc-deployment-7c7477c7ff-5s7cs   0/1     Pending             0          0s
pc-deployment-7c7477c7ff-5s7cs   0/1     Pending             0          0s
pc-deployment-7c7477c7ff-5s7cs   0/1     ContainerCreating   0          0s
pc-deployment-5d9c9b97bb-wwwgx   1/1     Terminating         0          11m
pc-deployment-5d9c9b97bb-wwwgx   0/1     Terminating         0          11m
pc-deployment-7c7477c7ff-5s7cs   0/1     ContainerCreating   0          1s
pc-deployment-7c7477c7ff-5s7cs   1/1     Running             0          2s      第二个
pc-deployment-5d9c9b97bb-vt9fl   1/1     Terminating         0          15m
pc-deployment-5d9c9b97bb-vt9fl   1/1     Terminating         0          15m
pc-deployment-5d9c9b97bb-vt9fl   0/1     Terminating         0          15m
pc-deployment-5d9c9b97bb-vt9fl   0/1     Terminating         0          15m
pc-deployment-5d9c9b97bb-vt9fl   0/1     Terminating         0          15m
pc-deployment-5d9c9b97bb-wwwgx   0/1     Terminating         0          11m
pc-deployment-5d9c9b97bb-wwwgx   0/1     Terminating         0          11m

#查看对应的pod
[root@master podcontroller]# kubectl get po -n dev -o wide
NAME                             READY   STATUS    RESTARTS   AGE     IP             NODE      NOMINATED NODE   READINESS GATES
pc-deployment-7c7477c7ff-5s7cs   1/1     Running   0          2m59s   10.18.189.88   worker2   <none>           <none>
pc-deployment-7c7477c7ff-sv9h7   1/1     Running   0          5m18s   10.18.189.87   worker2   <none>           <none>

#观察rs变化
# 查看rs,发现原来的rs的依旧存在，只是pod数量变为了0，而后又新产生了一个rs，pod数量为2
# 其实这就是deployment能够进行版本回退的奥妙所在，后面会详细解释
[root@master podcontroller]# kubectl get rs -n dev
NAME                       DESIRED   CURRENT   READY   AGE
pc-deployment-5d9c9b97bb   0         0         0       20m
pc-deployment-7c7477c7ff   2         2         2       7m1s
```



---版本回退

```
deployment支持版本升级过程中的暂停、继续功能以及版本回退等诸多功能，下面具体来看.

kubectl rollout： 版本升级相关功能，支持下面的选项：

status 显示当前升级状态
history 显示 升级历史记录
pause 暂停版本升级过程
resume 继续已经暂停的版本升级过程
restart 重启版本升级过程
undo 回滚到上一级版本（可以使用–to-revision回滚到指定版本）
```



查看当前升级状态

```sh
kubectl rollout status deploy pc-deployment -n dev

# 查看升级历史记录
[root@master podcontroller]# kubectl rollout history deploy pc-deployment -n dev
deployment.apps/pc-deployment 
REVISION  CHANGE-CAUSE
1         kubectl create --filename=pc-deployment.yaml --record=true
2         kubectl create --filename=pc-deployment.yaml --record=true

# 回退到1版本，不指定默认就是上一个，这里我指定为1
kubectl rollout undo deployment pc-deployment --to-revision=1 -n dev

#查看回到升级前的第一版
[root@master podcontroller]# kubectl get deploy -n dev -o wide
NAME            READY   UP-TO-DATE   AVAILABLE   AGE   CONTAINERS   IMAGES         SELECTOR
pc-deployment   2/2     2            2           26m   nginx        nginx:1.17.1   app=nginx-pod

#查看rs
[root@master podcontroller]# kubectl get rs -n dev
NAME                       DESIRED   CURRENT   READY   AGE
pc-deployment-5d9c9b97bb   2         2         2       28m
pc-deployment-7c7477c7ff   0         0         0       14m

# 查看rs，发现第一个rs中有2个pod运行，后面两个版本的rs中pod为运行
# 其实deployment之所以可是实现版本的回滚，就是通过记录下历史rs来实现的，
# 一旦想回滚到哪个版本，只需要将当前版本pod数量降为0，然后将回滚版本的pod提升为目标数量就可以了

```



---金丝雀发布（灰度发布）

```
Deployment控制器支持控制更新过程中的控制，如“暂停(pause)”或“继续(resume)”更新操作。

比如有一批新的Pod资源创建完成后立即暂停更新过程，此时，仅存在一部分新版本的应用，主体部分还是旧的版本。然后，再筛选一小部分的用户请求路由到新版本的Pod应用，继续观察能否稳定地按期望的方式运行。确定没问题之后再继续完成余下的Pod资源滚动更新，否则立即回滚更新操作。这就是所谓的金丝雀发布。
```



更新deployment版本，并配置暂停deployment

```sh
[root@master podcontroller]# kubectl set image deploy  pc-deployment nginx=nginx:1.17.4 -n dev && kubectl rollout pause deployment pc-deployment -n dev
deployment.apps/pc-deployment image updated
deployment.apps/pc-deployment paused


#观察更新状态
[root@master podcontroller]# kubectl rollout status deploy pc-deployment -n dev
Waiting for deployment "pc-deployment" rollout to finish: 1 out of 2 new replicas have been updated...
Waiting for deployment "pc-deployment" rollout to finish: 1 out of 2 new replicas have been updated...

# 监控更新过程，发现新增了一个资源（1.17.4）。但没有按照预期状态去删除一个旧的资源，就是因为使用了pause暂停命令，
# 原来的没变，新的增加了一部分，发现新的稳定运行，继续更新新的，最后删除旧的，剩下两个1.17.4
[root@master podcontroller]# kubectl get rs -n dev -o wide
NAME                       DESIRED   CURRENT   READY   AGE     CONTAINERS   IMAGES         SELECTOR
pc-deployment-5d9c9b97bb   2         2         2       36m     nginx        nginx:1.17.1   app=nginx-pod,pod-template-hash=5d9c9b97bb
pc-deployment-6b575b9c45   1         1         1       2m14s   nginx        nginx:1.17.4   app=nginx-pod,pod-template-hash=6b575b9c45
pc-deployment-7c7477c7ff   0         0         0       23m     nginx        nginx:1.17.2   app=nginx-pod,pod-template-hash=7c7477c7ff

[root@master podcontroller]# kubectl get po -n dev -o wide
NAME                             READY   STATUS    RESTARTS   AGE     IP              NODE      NOMINATED NODE   READINESS GATES
pc-deployment-5d9c9b97bb-8tnh7   1/1     Running   0          12m     10.18.235.142   worker1   <none>           <none>
pc-deployment-5d9c9b97bb-kcptw   1/1     Running   0          12m     10.18.235.143   worker1   <none>           <none>
pc-deployment-6b575b9c45-xzp52   1/1     Running   0          4m34s   10.18.189.89    worker2   <none>           <none>

#确保更新的pod没问题了，继续更新
[root@master podcontroller]# kubectl rollout resume deploy pc-deployment -n dev
deployment.apps/pc-deployment resumed

# 查看更新结果，看到1.17.4 两个副本都是1.17.4
# 过程：原来的没变，新的增加了一部分，发现新的稳定运行，继续更新新的，最后删除旧的，剩下两个1.17.4
[root@master podcontroller]# kubectl get rs -n dev -o wide
NAME                       DESIRED   CURRENT   READY   AGE     CONTAINERS   IMAGES         SELECTOR
pc-deployment-5d9c9b97bb   0         0         0       40m     nginx        nginx:1.17.1   app=nginx-pod,pod-template-hash=5d9c9b97bb
pc-deployment-6b575b9c45   2         2         2       5m43s   nginx        nginx:1.17.4   app=nginx-pod,pod-template-hash=6b575b9c45
pc-deployment-7c7477c7ff   0         0         0       26m     nginx        nginx:1.17.2   app=nginx-pod,pod-template-hash=7c7477c7ff

#删除delpoyment
[root@master podcontroller]# kubectl delete -f pc-deployment.yaml 
deployment.apps "pc-deployment" deleted
[root@master podcontroller]# kubectl get deploy -n dev -o wide
No resources found in dev namespace.
[root@master podcontroller]# kubectl get pod -n dev -o wide
No resources found in dev namespace.

```



--HPA( Horizontal Pod Autoscaler)  水平Pod自动缩放器



```
在前面的课程中，我们已经可以实现通过手工执行kubectl scale命令实现Pod扩容或缩容，但是这显然不符合Kubernetes的定位目标–自动化、智能化。 Kubernetes期望可以实现通过监测Pod的使用情况，实现pod数量的自动调整，于是就产生了Horizontal Pod Autoscaler（HPA）这种控制器。

HPA可以获取每个Pod利用率，然后和HPA中定义的指标进行对比，同时计算出需要伸缩的具体值，最后实现Pod的数量的调整。其实HPA与之前的Deployment一样，也属于一种Kubernetes资源对象，它通过追踪分析RC控制的所有目标Pod的负载变化情况，来确定是否需要针对性地调整目标Pod的副本数，这是HPA的实现原理。
```

HPA-deployment-replicaset-pod  更高级别的调度实现控制器



```
安装metrics-server
metrics-server可以用来收集集群中的资源使用情况

---- 连接github 443 后面要解决下，今天先不验证这个
```





--DaemonSet

```
DaemonSet类型的控制器可以保证在集群中的每一台（或指定）节点上都运行一个副本。一般适用于日志收集、节点监控等场景。也就是说，如果一个Pod提供的功能是节点级别的（每个节点都需要且只需要一个），那么这类Pod就适合使用DaemonSet类型的控制器创建。
```

```
DaemonSet控制器的特点：

每当向集群中添加一个节点时，指定的 Pod 副本也将添加到该节点上
当节点从集群中移除时，Pod 也就被垃圾回收了
```

DaemonSet清单文件

```yaml
apiVersion: apps/v1 # 版本号
kind: DaemonSet # 类型       
metadata: # 元数据
  name: # rs名称 
  namespace: # 所属命名空间 
  labels: #标签
    controller: daemonset
spec: # 详情描述
  revisionHistoryLimit: 3 # 保留历史版本
  updateStrategy: # 更新策略
    type: RollingUpdate # 滚动更新策略
    rollingUpdate: # 滚动更新
      maxUnavailable: 1 # 最大不可用状态的 Pod 的最大值，可以为百分比，也可以为整数
  selector: # 选择器，通过它指定该控制器管理哪些pod
    matchLabels:      # Labels匹配规则
      app: nginx-pod
    matchExpressions: # Expressions匹配规则
      - {key: app, operator: In, values: [nginx-pod]}
  template: # 模板，当副本数量不足时，会根据下面的模板创建pod副本
    metadata:
      labels:
        app: nginx-pod
    spec:
      containers:
      - name: nginx
        image: nginx:1.17.1
        ports:
        - containerPort: 80
```



创建资源文件 pc-daemonset.yaml

```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: pc-daemonset
  namespace: dev
spec:
  selector:
    matchLabels:
      app: nginx-pod
  template:
    metadata:
      labels:
        app: nginx-pod
    spec:
      containers:
      - name: nginx
        image: nginx:1.17.1

```



```sh
kubectl create -f pc-daemonset.yaml

#查看状态，daemonset 简称 ds
kubectl get ds -n dev
NAME           DESIRED   CURRENT   READY   UP-TO-DATE   AVAILABLE   NODE SELECTOR   AGE
pc-daemonset   2         2         2       2            2           <none>          83s

#查看pod,可以看到每个节点上都有一个pod,daemonset就是控制在每个节点都有一份
kubectl get pods -n dev -o wide
NAME                 READY   STATUS    RESTARTS   AGE     IP              NODE      NOMINATED NODE   READINESS GATES
pc-daemonset-bt6db   1/1     Running   0          2m24s   10.18.235.144   worker1   <none>           <none>
pc-daemonset-w2wd9   1/1     Running   0          2m24s   10.18.189.91    worker2   <none>           <none>

#删除daemonset
kubectl delete -f pc-daemonset.yaml  文件方式
kubectl delete ds pc-daemonset -n dev  命令方式

# 查看删除结果
[root@master podcontroller]# kubectl get pods -n dev -o wide
No resources found in dev namespace.
[root@master podcontroller]# kubectl get ds -n dev
No resources found in dev namespace.
```



--Job

```
Job，主要用于负责**批量处理(一次要处理指定数量任务)短暂的一次性(每个任务仅运行一次就结束)**任务。Job特点如下：

当Job创建的pod执行成功结束时，Job将记录成功结束的pod数量
当成功结束的pod达到指定的数量时，Job将完成执行
```



Job清单

```yaml
apiVersion: batch/v1 # 版本号
kind: Job # 类型       
metadata: # 元数据
  name: # rs名称 
  namespace: # 所属命名空间 
  labels: #标签
    controller: job
spec: # 详情描述
  completions: 1 # 指定job需要成功运行Pods的次数。默认值: 1
  parallelism: 1 # 指定job在任一时刻应该并发运行Pods的数量。默认值: 1
  activeDeadlineSeconds: 30 # 指定job可运行的时间期限，超过时间还未结束，系统将会尝试进行终止。
  backoffLimit: 6 # 指定job失败后进行重试的次数。默认是6
  manualSelector: true # 是否可以使用selector选择器选择pod，默认是false
  selector: # 选择器，通过它指定该控制器管理哪些pod
    matchLabels:      # Labels匹配规则
      app: counter-pod
    matchExpressions: # Expressions匹配规则
      - {key: app, operator: In, values: [counter-pod]}
  template: # 模板，当副本数量不足时，会根据下面的模板创建pod副本
    metadata:
      labels:
        app: counter-pod
    spec:
      restartPolicy: Never # 重启策略只能设置为Never或者OnFailure
      containers:
      - name: counter
        image: busybox:1.30
        command: ["bin/sh","-c","for i in 9 8 7 6 5 4 3 2 1; do echo $i;sleep 2;done"]
```

```
关于重启策略设置的说明：
    如果指定为OnFailure，则job会在pod出现故障时重启容器，而不是创建pod，failed次数不变
    如果指定为Never，则job会在pod出现故障时创建新的pod，并且故障pod不会消失，也不会重启，failed次数加1
    如果指定为Always的话，就意味着一直重启，意味着job任务会重复去执行了，当然不对，所以不能设置为Always
```



创建资源文件pc-job.yaml

```yaml
apiVersion: batch/v1
kind: Job
metadata:
  name: pc-job
  namespace: dev
spec:
  manualSelector: true
  selector:
    matchLabels:
      app: counter-pod
  template:
    metadata:
      labels:
        app: counter-pod
    spec:
      restartPolicy: Never
      containers:
      - name: counter
        image: busybox:1.30
        command: ["bin/sh","-c","for i in 9 8 7 6 5 4 3 2 1; do echo $i;sleep 3;done"]

```



```sh
# 创建job
kubectl create -f pc-job.yaml 


# 查看创建过程
[root@master podcontroller]# kubectl get job -n dev -o wide -w
NAME     COMPLETIONS   DURATION   AGE   CONTAINERS   IMAGES         SELECTOR
pc-job   1/1           29s        58s   counter      busybox:1.30   app=counter-pod

# 接下来，调整下pod运行的总数量和并行数量 即：在spec下设置下面两个选项
#  completions: 6 # 指定job需要成功运行Pods的次数为6
#  parallelism: 3 # 指定job并发运行Pods的数量为3

#  然后重新运行job，观察效果，此时会发现，job会每次运行3个pod，总共执行了6个pod

#删除
kubectl delete -f pc-job.yaml 
job.batch "pc-job" deleted

# 添加配置
spec:
  backoffLimit: 6  
  completions: 6 1 >> 6
  manualSelector: true
  parallelism: 3  1 >> 3
#创建资源对象，也就是重新运行job
 kubectl create -f pc-job.yaml 
job.batch/pc-job created
# 监控创建状态
kubectl get pods -n dev -w
NAME           READY   STATUS    RESTARTS   AGE
pc-job-h6pdl   1/1     Running   0          3s
pc-job-nhpbz   1/1     Running   0          3s
pc-job-z442g   1/1     Running   0          3s
pc-job-h6pdl   0/1     Completed   0          28s
pc-job-jj6jc   0/1     Pending     0          0s
pc-job-jj6jc   0/1     Pending     0          0s
pc-job-z442g   0/1     Completed   0          28s
pc-job-m6sl5   0/1     Pending     0          0s
pc-job-jj6jc   0/1     ContainerCreating   0          0s
pc-job-m6sl5   0/1     Pending             0          0s
pc-job-m6sl5   0/1     ContainerCreating   0          0s
pc-job-h6pdl   0/1     Completed           0          28s
pc-job-nhpbz   0/1     Completed           0          28s
pc-job-zppln   0/1     Pending             0          0s
pc-job-zppln   0/1     Pending             0          0s
pc-job-zppln   0/1     ContainerCreating   0          0s
pc-job-z442g   0/1     Completed           0          28s
pc-job-nhpbz   0/1     Completed           0          28s
pc-job-zppln   0/1     ContainerCreating   0          1s
pc-job-m6sl5   0/1     ContainerCreating   0          1s
pc-job-jj6jc   0/1     ContainerCreating   0          1s
pc-job-zppln   1/1     Running             0          1s
pc-job-m6sl5   1/1     Running             0          2s
pc-job-jj6jc   1/1     Running             0          2s
pc-job-zppln   0/1     Completed           0          28s  1 
pc-job-zppln   0/1     Completed           0          29s  2
pc-job-jj6jc   0/1     Completed           0          29s  3
pc-job-m6sl5   0/1     Completed           0          29s  4
pc-job-jj6jc   0/1     Completed           0          29s  5
pc-job-m6sl5   0/1     Completed           0          30s  6

# 最后删除
kubectl delete -f pc-job.yaml
```



--cornjob(cj)

```
CronJob控制器以 Job控制器资源为其管控对象，并借助它管理pod资源对象，
Job控制器定义的作业任务在其控制器资源创建之后便会立即执行，但CronJob可以以类似于Linux操作系统的周期性任务作业计划的方式控制其运行时间点及重复运行的方式。也就是说，CronJob可以在特定的时间点(反复的)去运行job任务。
```

清单文件

```yaml
apiVersion: batch/v1beta1 # 版本号
kind: CronJob # 类型       
metadata: # 元数据
  name: # rs名称 
  namespace: # 所属命名空间 
  labels: #标签
    controller: cronjob
spec: # 详情描述
  schedule: # cron格式的作业调度运行时间点,用于控制任务在什么时间执行
  concurrencyPolicy: # 并发执行策略，用于定义前一次作业运行尚未完成时是否以及如何运行后一次的作业
  failedJobHistoryLimit: # 为失败的任务执行保留的历史记录数，默认为1
  successfulJobHistoryLimit: # 为成功的任务执行保留的历史记录数，默认为3
  startingDeadlineSeconds: # 启动作业错误的超时时长
  jobTemplate: # job控制器模板，用于为cronjob控制器生成job对象;下面其实就是job的定义
    metadata:
    spec:
      completions: 1
      parallelism: 1
      activeDeadlineSeconds: 30
      backoffLimit: 6
      manualSelector: true
      selector:
        matchLabels:
          app: counter-pod
        matchExpressions: 规则
          - {key: app, operator: In, values: [counter-pod]}
      template:
        metadata:
          labels:
            app: counter-pod
        spec:
          restartPolicy: Never 
          containers:
          - name: counter
            image: busybox:1.30
            command: ["bin/sh","-c","for i in 9 8 7 6 5 4 3 2 1; do echo $i;sleep 20;done"]
```

```
需要重点解释的几个选项：
schedule: cron表达式，用于指定任务的执行时间
    */1    *      *    *     *
    <分钟> <小时> <日> <月份> <星期>

    分钟 值从 0 到 59.
    小时 值从 0 到 23.
    日 值从 1 到 31.
    月 值从 1 到 12.
    星期 值从 0 到 6, 0 代表星期日
    多个时间可以用逗号隔开； 范围可以用连字符给出；*可以作为通配符； /表示每...
concurrencyPolicy:
    Allow:   允许Jobs并发运行(默认)
    Forbid:  禁止并发运行，如果上一次运行尚未完成，则跳过下一次运行
    Replace: 替换，取消当前正在运行的作业并用新作业替换它
```



创建资源对象

```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: pc-cronjob
  namespace: dev
  labels:
    controller: cronjob
spec:
  schedule: "*/1 * * * *"
  jobTemplate:
    metadata:
    spec:
      template:
        spec:
          restartPolicy: Never
          containers:
          - name: counter
            image: busybox:1.30
            command: ["bin/sh","-c","for i in 9 8 7 6 5 4 3 2 1;do echo $i; sleep 3;done"]
```



创建cronjob资源对象

```sh
 kubectl create -f pc-cronjob.yaml 
 
# 查看cronjobs   
kubectl get cronjobs -n dev
NAME         SCHEDULE      SUSPEND   ACTIVE   LAST SCHEDULE   AGE
pc-cronjob   */1 * * * *   False     1        24s             91s

# 查看job， 可以看到每个job间隔时间是60s也就是每分钟执行这个job任务,这个job序号是数字，而且是递增的
kubectl get job -n dev
NAME                  COMPLETIONS   DURATION   AGE
pc-cronjob-28722297   1/1           28s        3m28s
pc-cronjob-28722298   1/1           28s        2m28s
pc-cronjob-28722299   1/1           28s        88s
pc-cronjob-28722300   0/1           28s        28s

# 查看pods
kubectl get pods -n dev
NAME                        READY   STATUS      RESTARTS   AGE
pc-cronjob-28722299-wmd6p   0/1     Completed   0          2m50s
pc-cronjob-28722300-l46kw   0/1     Completed   0          110s
pc-cronjob-28722301-8lrpm   0/1     Completed   0          50s

#删除cronjobs
kubectl delete -f  pc-cronjob.yaml 
```



## 6.Service-更进一步使用

```
在kubernetes中，pod是应用程序的载体，我们可以通过pod的ip来访问应用程序，但是pod的ip地址不是固定的，这也就意味着不方便直接采用pod的ip对服务进行访问。

为了解决这个问题，kubernetes提供了Service资源，Service会对提供同一个服务的多个pod进行聚合，并且提供一个统一的入口地址。通过访问Service的入口地址就能访问到后面的pod服务
```

![img](k8s学习记录.assets/202307031708395.png)

```
Service在很多情况下只是一个概念，真正起作用的其实是kube-proxy服务进程，每个Node节点上都运行着一个kube-proxy服务进程。当创建Service的时候会通过api-server向etcd写入创建的service的信息，而kube-proxy会基于监听的机制发现这种Service的变动，然后它会将最新的Service信息转换成对应的访问规则
```

![img](k8s学习记录.assets/202307031708283.png)

kube-proxy三种模式

--userspace模式

```
userspace模式下，kube-proxy会为每一个Service创建一个监听端口，发向Cluster IP的请求被Iptables规则重定向到kube-proxy监听的端口上，kube-proxy根据LB算法选择一个提供服务的Pod并和其建立链接，以将请求转发到Pod上。 该模式下，kube-proxy充当了一个四层负责均衡器的角色。由于kube-proxy运行在userspace中，在进行转发处理时会增加内核和用户空间之间的数据拷贝，虽然比较稳定，但是效率比较低。
```

![img](k8s学习记录.assets/202307031708863.png)



--iptables模式

```
iptables模式下，kube-proxy为service后端的每个Pod创建对应的iptables规则，直接将发向Cluster IP的请求重定向到一个Pod IP。 该模式下kube-proxy不承担四层负责均衡器的角色，只负责创建iptables规则。该模式的优点是较userspace模式效率更高，但不能提供灵活的LB策略，当后端Pod不可用时也无法进行重试。
```

![img](k8s学习记录.assets/202307031708663.png)

--ipvs模式

不太理解这个

```

ipvs模式和iptables类似，kube-proxy监控Pod的变化并创建相应的ipvs规则。ipvs相对iptables转发效率更高。除此以外，ipvs支持更多的LB算法。
```

![img](k8s学习记录.assets/202307031708471.png)

```sh
#必须安装ipvs模块，否则会降级为iptables
ipvsadm -Ln

#开启ipvs
 kubectl edit cm kube-proxy -n kube-system  # 将mode=" " 改为 mode="ipvs"

# 将mode=" " 改为 mode="ipvs"
kubectl delete pod -l k8s-app=kube-proxy -n kube-system

#查看ipvs
ipvsadm -Ln
IP Virtual Server version 1.2.1 (size=4096)
Prot LocalAddress:Port Scheduler Flags
  -> RemoteAddress:Port           Forward Weight ActiveConn InActConn
TCP  10.10.0.10:53 rr
TCP  10.10.116.111:80 rr
TCP  10.18.219.64:30002 rr
TCP  10.18.219.64:31009 rr
TCP  10.18.219.64:31748 rr
  -> 10.18.235.129:80             Masq    1      0          0         
TCP  127.0.0.1:30002 rr
TCP  127.0.0.1:31009 rr
TCP  127.0.0.1:31748 rr
  -> 10.18.235.129:80             Masq    1      0          0         
TCP  172.17.0.1:30002 rr
TCP  172.17.0.1:31009 rr
TCP  172.17.0.1:31748 rr
  -> 10.18.235.129:80             Masq    1      0          0         
TCP  192.168.93.6:30002 rr
TCP  192.168.93.6:31009 rr
TCP  192.168.93.6:31748 rr
  -> 10.18.235.129:80             Masq    1      0          0         
TCP  192.168.122.1:30002 rr
TCP  192.168.122.1:31009 rr
TCP  192.168.122.1:31748 rr
  -> 10.18.235.129:80             Masq    1      0          0         
TCP  10.10.0.1:443 rr
  -> 192.168.93.6:6443            Masq    1      0          0         
TCP  10.10.0.10:9153 rr
TCP  10.10.57.19:80 rr
TCP  10.10.116.110:80 rr
TCP  10.10.246.177:80 rr
  -> 10.18.235.129:80             Masq    1      0          0         
UDP  10.10.0.10:53 rr

```





service资源清单

```yaml
kind: Service  # 资源类型
apiVersion: v1  # 资源版本
metadata: # 元数据
  name: service # 资源名称
  namespace: dev # 命名空间
spec: # 描述
  selector: # 标签选择器，用于确定当前service代理哪些pod
    app: nginx
  type: # Service类型，指定service的访问方式
  clusterIP:  # 虚拟服务的ip地址
  sessionAffinity: # session亲和性，支持ClientIP、None两个选项
  ports: # 端口信息
    - protocol: TCP 
      port: 3017  # service端口
      targetPort: 5003 # pod端口
      nodePort: 31122 # 主机端口
```

```
ClusterIP：默认值，它是Kubernetes系统自动分配的虚拟IP，只能在集群内部访问
NodePort：将Service通过指定的Node上的端口暴露给外部，通过此方法，就可以在集群外部访问服务
LoadBalancer：使用外接负载均衡器完成到服务的负载分发，注意此模式需要外部云环境支持
ExternalName： 把集群外部的服务引入集群内部，直接使用
```

```
port: 3017定义了Service暴露给集群外部和内部的端口，targetPort:5003定义了将流量转发到后端Pod的容器端口。另外，type: NodePort将Service的类型设置为NodePort，允许通过每个节点的IP地址和随机高端口访问Service。

请注意，NodePort是一种简单的方式来暴露Service到集群外部，但在生产环境中，通常会使用更高级的负载均衡器或Ingress控制器来处理流量分发和SSL终止等更高级的功能。


理解这3个端口概念。理解一个模型

集群、服务、
一个k8s容器里面可能一个集群，可能多个集群；
一个集群可能一个服务，可能多个服务

关系就有这些：集群与集群之间、服务与服务之间、容器内和容器外。

1、如果本集群或者其他集群像要调用这个这个服务（service）,就通过这个3017端口

2、想要访问pod后端的容器端口  targetPort:5003 这个应该就是pod运行的端口了。例如springBoot就是9003。
		需要指定到服务运行的端口，也就是tomcat的端口或者nginx真正提供的目标端口。如果是nginx,而自己有没有手动去改配置文件的端口，那么端口就是80了
		这就是后端pod容器的端口

3、在集群的外部环境，也就是在k8s之外的环境进行访问，就是nodeport的作用了。用节点IP+nodeport就可以访问盘pod了。

4、大概位置
          -> 3017
                      ->5003
-> 31122
5、访问顺序
如果在宿主机上访问，则顺序是    curl http://localhost:31122
流量顺序是 nodeport的31122的流量转发到，port的3017，service的3017将流量转发到pod的5003上。
   service其实就是pod的nginx的作用，目的是被代理访问

```





创建deployment.yaml

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: pc-deployment
  namespace: dev
spec:
  replicas: 3
  selector:
    matchLabels:
      app: nginx-pod
  template:
    metadata:
      labels:
        app: nginx-pod
    spec:
      containers:
      - name: nginx
        image: nginx:1.17.1
        ports:
          - containerPort: 80

```

创建deployment资源对象

```sh
#
 kubectl create -f deployment.yaml 
 
# 查看对应的pod
[root@master service]# kubectl get pods -n dev -o wide --show-labels
NAME                             READY   STATUS    RESTARTS   AGE   IP              NODE      NOMINATED NODE   READINESS GATES   LABELS
pc-deployment-5ffc5bf56c-bck7j   1/1     Running   0          67s   10.18.235.147   worker1   <none>           <none>            app=nginx-pod,pod-template-hash=5ffc5bf56c
pc-deployment-5ffc5bf56c-j8r7h   1/1     Running   0          67s   10.18.189.107   worker2   <none>           <none>            app=nginx-pod,pod-template-hash=5ffc5bf56c
pc-deployment-5ffc5bf56c-x8cnq   1/1     Running   0          67s   10.18.189.108   worker2   <none>           <none>            app=nginx-pod,pod-template-hash=5ffc5bf56c

#修改三台nginx的index.html
kubectl exec -it pc-deployment-5ffc5bf56c-bck7j -n dev /bin/sh
echo "10.18.235.147" > /usr/share/nginx/html/index.html
kubectl exec -it pc-deployment-5ffc5bf56c-j8r7h -n dev /bin/sh
echo "10.18.189.107" > /usr/share/nginx/html/index.html
kubectl exec -it pc-deployment-5ffc5bf56c-x8cnq -n dev /bin/sh
echo "10.18.189.108" > /usr/share/nginx/html/index.html


--这几步把service需要环境搞好了，下面测试service的类型
```



---ClusterIP类型的Service

创建service

```yaml
apiVersion: v1
kind: Service
metadata:
  name: service-clusterip
  namespace: dev
spec:
  selector:
    app: nginx-pod
  clusterIP:   # 这里不写会默认生成一个
  type: ClusterIP
  ports:
  - port: 80 # Service端口
    targetPort: 80  # pod端口
```

创建service资源对象

```sh
kubectl create -f service-clusterip.yaml 
service/service-clusterip created

#查看service
kubectl get svc -n dev -o wide
NAME                TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)        AGE     SELECTOR
service-clusterip   ClusterIP   10.10.63.221    <none>        80/TCP         21s     app=nginx-pod

#查看service详细信息，
# 这里面有一个endpoints列表，里面就是当前service可以负载到的服务入口
kubectl describe svc service-clusterip -n dev

Name:              service-clusterip
Namespace:         dev
Labels:            <none>
Annotations:       <none>
Selector:          app=nginx-pod
Type:              ClusterIP
IP Family Policy:  SingleStack
IP Families:       IPv4
IP:                10.10.63.221
IPs:               10.10.63.221
Port:              <unset>  80/TCP
TargetPort:        80/TCP
Endpoints:         10.18.189.107:80,10.18.189.108:80,10.18.235.147:80
Session Affinity:  None
Events:            <none>

#查看ipvs规则
ipvsadm -Ln
IP Virtual Server version 1.2.1 (size=4096)
Prot LocalAddress:Port Scheduler Flags
  -> RemoteAddress:Port  
TCP  10.10.63.221:80 rr
  -> 10.18.189.107:80             Masq    1      0          0         
  -> 10.18.189.108:80             Masq    1      0          0         
  -> 10.18.235.147:80             Masq    1      0          0  
  
#访问ipvs  10.10.63.221:80 观察结果  
[root@master service]# curl 10.10.63.221:80
10.18.235.147
[root@master service]# curl 10.10.63.221:80
10.18.189.108
[root@master service]# 
[root@master service]# curl 10.10.63.221:80
10.18.189.107
 
```



----endpoints

```
Endpoint是kubernetes中的一个资源对象，存储在etcd中，用来记录一个service对应的所有pod的访问地址，它是根据service配置文件中selector描述产生的。

一个Service由一组Pod组成，这些Pod通过Endpoints暴露出来，Endpoints是实现实际服务的端点集合。换句话说，service和pod之间的联系是通过endpoints实现的。
```

![image-20200509191917069](k8s学习记录.assets/202307031708837.png)

```sh
kubectl get endpoints -n dev -o wide
NAME                ENDPOINTS                                            AGE
service-clusterip   10.18.189.107:80,10.18.189.108:80,10.18.235.147:80   15m

```

负载分发策略

```
对Service的访问被分发到了后端的Pod上去，目前kubernetes提供了两种负载分发策略：

如果不定义，默认使用kube-proxy的策略，比如随机、轮询

基于客户端地址的会话保持模式，即来自同一个客户端发起的所有请求都会转发到固定的一个Pod上
	此模式可以使在spec中添加sessionAffinity:ClientIP选项
```



```sh
# 查看ipvs规则 【rr 轮询】
ipvsadm -Ln

#循环访问测试
while true;do curl 10.10.63.221:80;sleep 5; done;
10.18.235.147
10.18.189.108
10.18.189.107
10.18.235.147
10.18.189.108
10.18.189.107
10.18.235.147

#修改分发策略
kubectl edit svc service-clusterip -n dev
# 修改 sessionAffinity:None > sessionAffinity:ClientIP
spec:
  sessionAffinity: ClientIP
# 查看规则
ipvsadm -Ln    # persistent 持久

TCP  10.10.63.221:80 rr persistent 10800
  -> 10.18.189.107:80             Masq    1      0          0         
  -> 10.18.189.108:80             Masq    1      0          0         
  -> 10.18.235.147:80             Masq    1      0          0 
  
  
# 循环访问测试
while true;do curl 10.10.63.221:80;sleep 5; done;

[root@master service]# while true;do curl 10.10.63.221:80;sleep 5; done;
10.18.189.108
10.18.189.108
10.18.189.108
10.18.189.108

# 删除service
 kubectl delete -f service-clusterip.yaml 
```



--HeadLiness类型的service

```
在某些场景中，开发人员可能不想使用Service提供的负载均衡功能，而希望自己来控制负载均衡策略，针对这种情况，kubernetes提供了HeadLiness Service，这类Service不会分配Cluster IP，如果想要访问service，只能通过service的域名进行查询。
```

service-headliness.yaml

```yaml
apiVersion: v1
kind: Service
metadata:
  name: service-headliness
  namespace: dev
spec:
  selector:
    app: nginx-pod
  clusterIP: None #设置为None,即可创建HeadLiness Service
  type: ClusterIP
  ports:
  - port: 80
    targetPort: 80

```



```sh
kubectl create -f service-headliness.yaml 

kubectl get svc -n dev -o wide
NAME                 TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)        AGE    SELECTOR
service-headliness   ClusterIP   None            <none>        80/TCP         19s    app=nginx-pod

#查看详情
kubectl describe svc service-headliness -n dev
Name:              service-headliness
Namespace:         dev
Labels:            <none>
Annotations:       <none>
Selector:          app=nginx-pod
Type:              ClusterIP
IP Family Policy:  SingleStack
IP Families:       IPv4
IP:                None
IPs:               None
Port:              <unset>  80/TCP
TargetPort:        80/TCP
Endpoints:         10.18.189.107:80,10.18.189.108:80,10.18.235.147:80
Session Affinity:  None
Events:            <none>

#查看域名解析	情况
kubectl exec -it pc-deployment-5ffc5bf56c-bck7j -n dev /bin/sh

cat /etc/resolv.conf
nameserver 10.10.0.10
search dev.svc.cluster.local svc.cluster.local cluster.local
options ndots:5

# 域名解析
dig @10.10.0.10 service-headliness.dev.svc.cluster.local
这里发现之前的coredns有问题

修改镜像版本改成,多加了一个v  1.8.0->v1.8.0

# 这个是k8s需要构建的镜像 
kubectl get pods coredns-545d6fc579-hscqh -n kube-system -o yaml | grep image:

image: registry.aliyuncs.com/google_containers/coredns/coredns:v1.8.0
  - image: registry.aliyuncs.com/google_containers/coredns/coredns:v1.8.0


# 拉取镜像
docker pull coredns/coredns:1.8.0

#仓库里面镜像为
docker images
coredns/coredns                  1.8.0             296a6d5035e2   3 years ago   42.5MB

#需要把仓库里面的 tag 为 1.8.0 改为 v1.8.0
docker tag 296a6d5035e2 registry.aliyuncs.com/google_containers/coredns/coredns:v1.8.0

#查看coredns
kubectl get pod -n kube-system

域名解析服务已正常，可以使用dig完成域名解析
```



-- NodePort类型的Service

```
在之前的样例中，创建的Service的ip地址只有集群内部才可以访问，如果希望将Service暴露给集群外部使用，那么就要使用到另外一种类型的Service，称为NodePort类型。NodePort的工作原理其实就是将service的端口映射到Node的一个端口上，然后就可以通过NodeIp:NodePort来访问service了。
```

![img](k8s学习记录.assets/202307031708431.png)

service-nodeport.yaml

```yaml
apiVersion: v1
kind: Service
metadata:
  name: service-nodeport
  namespace: dev
spec:
  selector:
    app: nginx-pod
  type: NodePort
  ports:
  - port: 80
    nodePort: 30002
```



创建资源对象

```sh
kubectl create -f service-nodeport.yaml

查看service
[root@master service]# kubectl get svc service-nodeport -n dev -o wide
NAME               TYPE       CLUSTER-IP    EXTERNAL-IP   PORT(S)        AGE     SELECTOR
service-nodeport   NodePort   10.10.57.19   <none>        80:30002/TCP   3d22h   app=nginx-pod

```



--loadbalancer类型的service

```
LoadBalancer和NodePort很相似，目的都是向外部暴露一个端口，区别在于LoadBalancer会在集群的外部再来做一个负载均衡设备，而这个设备需要外部环境支持的，外部服务发送到这个设备上的请求，会被设备负载之后转发到集群中。
```

![img](k8s学习记录.assets/202307031709551.png)





--ExternalName类型的service

```
ExternalName类型的Service用于引入集群外部的服务，它通过externalName属性指定外部一个服务的地址，然后在集群内部访问此service就可以访问到外部的服务了。
```

![img](k8s学习记录.assets/202307031709083.png)



创建资源文件

service-nodeport.yaml

```yaml
apiVersion: v1
kind: Service
metadata:
  name: service-externalname
  namespace: dev
spec:
  type: ExternalName  # service类型
  externalName: www.baidu.com  #改成ip址也可以
```





```sh
kubectl create -f  service-nodeport.yaml

# 域名解析
dig @10.10.0.10 service-externalname.dev.svc.cluster.local

```





--ingress

```
在前面课程中已经提到，Service对集群之外暴露服务的主要方式有两种：NotePort和LoadBalancer，但是这两种方式，都有一定的缺点：

	NodePort方式的缺点是会占用很多集群机器的端口，那么当集群服务变多的时候，这个缺点就愈发明显
	LB方式的缺点是每个service需要一个LB，浪费、麻烦，并且需要kubernetes之外设备的支持
基于这种现状，kubernetes提供了Ingress资源对象，Ingress只需要一个NodePort或者一个LB就可以满足暴露多个Service的需求。工作机制大致如下图表示：
```

![img](k8s学习记录.assets/202307031709107.png)



```
实际上，Ingress相当于一个7层的负载均衡器，是kubernetes对反向代理的一个抽象，它的工作原理类似于Nginx，可以理解成在Ingress里建立诸多映射规则，Ingress Controller通过监听这些配置规则并转化成Nginx的反向代理配置 , 然后对外部提供服务。在这里有两个核心概念：

    ingress：kubernetes中的一个对象，作用是定义请求如何转发到service的规则
    ingress controller：具体实现反向代理及负载均衡的程序，对ingress定义的规则进行解析，根据配置的规则来实现请求转发，实现方式有很多，比如Nginx, Contour, Haproxy等等
    
    
Ingress（以Nginx为例）的工作原理如下：

    用户编写Ingress规则，说明哪个域名对应kubernetes集群中的哪个Service
    Ingress控制器动态感知Ingress服务规则的变化，然后生成一段对应的Nginx反向代理配置
    Ingress控制器会将生成的Nginx配置写入到一个运行着的Nginx服务中，并动态更新
    到此为止，其实真正在工作的就是一个Nginx了，内部配置了用户定义的请求转发规则
```



![img](k8s学习记录.assets/202307031709614.png)



ingress其实就是对 对外暴露service类型的service进行的一次增强包装，就是引入ingress；

理解为一个pod资源对象就好，作用是类似nginx的,只不过k8s对其包装过了



准备ingress环境

```sh
mkdir ingress-controller
cd ingress-controller


# 获取ingress-nginx
wget https://raw.githubusercontent.com/kubernetes/ingress-nginx/nginx-0.30.0/deploy/static/mandatory.yaml


 wget https://raw.githubusercontent.com/kubernetes/ingress-nginx/nginx-0.30.0/deploy/static/provider/baremetal/service-nodeport.yaml
 
 
 # 修改mandatory.yaml文件中的仓库
# 修改quay.io/kubernetes-ingress-controller/nginx-ingress-controller:0.30.0
# 为quay-mirror.qiniu.com/kubernetes-ingress-controller/nginx-ingress-controller:0.30.0

不用改，改了反而拉不下来镜像
# 创建ingress-nginx
  kubectl apply -f ./
 
 
#查看ingress-nginx
 kubectl get pod -n ingress-nginx
 
#查看service  这里看来 这个 ingress-service  就是一种service
kubectl get svc -n ingress-nginx
```



```
为了后面的实验比较方便，创建如下图所示的模型
```

![img](k8s学习记录.assets/202307031709513.png)

创建tomcat-nginx.yaml

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx-deployment
  namespace: dev
spec:
  replicas: 3
  selector:
    matchLabels:
      app: nginx-pod
  template:
    metadata:
      labels:
        app: nginx-pod
    spec:
      containers:
      - name: nginx
        image: nginx:1.17.1
        ports:
        - containerPort: 80

---

apiVersion: apps/v1
kind: Deployment
metadata:
  name: tomcat-deployment
  namespace: dev
spec:
  replicas: 3
  selector:
    matchLabels:
      app: tomcat-pod
  template:
    metadata:
      labels:
        app: tomcat-pod
    spec:
      containers:
      - name: tomcat
        image: tomcat:8.5-jre10-slim
        ports:
        - containerPort: 8080

---

apiVersion: v1
kind: Service
metadata:
  name: nginx-service
  nameservice: dev
spec:
  selector:
    app: nginx-pod
  clusterIP: None
  type: ClusterIP
  ports:
  - port: 80
    targetPort: 80

---

apiVersion: v1
kind: Service
metadata:
  name: tomcat-service
  namespace: dev
spec:
  selector:
    app: tomcat-pod
  clusterIP: None
  type: ClusterIP
  ports:
  - port: 8080
    targetPort: 8080



# 内容较多，有些大小写容易写错，很难排查，这里校验文件格式是否正确。这里kind  写成Kindl了， k->K  大小写
 kubectl apply -f tomcat-nginx.yaml --dry-run=client   # 这个是伪执行，，可以校验yaml文件错误。
 

# 再次运行  校验，全部通过
kubectl apply -f tomcat-nginx.yaml --dry-run=client
deployment.apps/nginx-deployment created (dry run)
deployment.apps/tomcat-deployment created (dry run)
service/nginx-service created (dry run)
service/tomcat-service created (dry run)


```



创建资源文件

```sh
kubectl create -f tomcat-nginx.yaml 


```



http代理

创建ingress-http.yaml

```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: ingress-http
  namespace: dev
spec:
  rules:
  - host: nginx.itheima.com
    http:
      paths:
      - path: /
        backend:
          serviceName: nginx-service
          servicePort: 80
  - host: tomcat.itheima.com
    http:
      paths:
      - path: /
        backend:
          serviceName: tomca
```



创建资源对象

```yaml
kubectl create  -f ingress-http.yaml

#删除  删除命令，暂不删除
kubectl delete  ingress ingress-http -n dev

这里warning先不管


#查看ingress
kubectl get ing -n dev

#查看详情
kubectl describe ing -n dev


# 接下来,在本地电脑上配置host文件,解析上面的两个域名到192.168.93.6(master)上
# 然后,就可以分别访问tomcat.itheima.com:32658  和  nginx.itheima.com:32658查看效果了
# 这个端口是 ingress-service的端口，查看命令
kubectl get svc -n ingress-nginx
ingress-nginx   NodePort   10.10.75.150   <none>        80:32658/TCP,443:30376/TCP   70m


C:\Windows\System32\drivers\etc\hosts

192.168.93.6 nginx.itheima.com
192.168.93.6 tomcat.itheima.com
```



--- 配置https

```sh
# 生成证书
openssl req -x509 -sha256 -nodes -days 365 -newkey rsa:2048 -keyout tls.key -out tls.crt -subj "/C=CN/ST=BJ/L=BJ/O=nginx/CN=itheima.com"

# 创建密钥
kubectl create secret tls tls-secret --key tls.key --cert tls.crt
```



创建资源文件 ingress-https>yaml

```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: ingress-https
  namespace: dev
spec:
  tls:
    - hosts:
      - nginx.itheima.com
      - tomcat.itheima.com
      secretName: tls-secret
  rules:
  - host: nginx.itheima.com
    http:
      paths:
      - path: /
        backend:
          serviceName: nginx-service
          servicePort: 80
  - host: tomcat.itheima.com
    http:
      paths:
      - path: /
        backend:
          serviceName: tomcat-service
          servicePort: 8080

```



创建资源对象

```sh
# 参加资源对象
kubectl create -f ingress-https.yaml

# 查看ingress
kubectl get ing ingress-https -n dev
NAME            CLASS    HOSTS                                  ADDRESS        PORTS     AGE
ingress-https   <none>   nginx.itheima.com,tomcat.itheima.com   10.10.75.150   80, 443   56s

# 查看详情
 kubectl get describe ingress-https -n dev
 
 
# 查看端口 ，通过https访问，这个443:30376就是https的访问端口
kubectl get svc -n ingress-nginx
NAME            TYPE       CLUSTER-IP     EXTERNAL-IP   PORT(S)                      AGE
ingress-nginx   NodePort   10.10.75.150   <none>        80:32658/TCP,443:30376/TCP   79m

https://tomcat.itheima.com:30376/
https://nginx.itheima.com:30376/
```



## 7.数据存储

```
在前面已经提到，容器的生命周期可能很短，会被频繁地创建和销毁。那么容器在销毁时，保存在容器中的数据也会被清除。这种结果对用户来说，在某些情况下是不乐意看到的。为了持久化保存容器的数据，kubernetes引入了Volume的概念。

Volume是Pod中能够被多个容器访问的共享目录，它被定义在Pod上，然后被一个Pod里的多个容器挂载到具体的文件目录下，kubernetes通过Volume实现同一个Pod中不同容器之间的数据共享以及数据的持久化存储。Volume的生命容器不与Pod中单个容器的生命周期相关，当容器终止或者重启时，Volume中的数据也不会丢失。

kubernetes的Volume支持多种类型，比较常见的有下面几个：

简单存储：EmptyDir、HostPath、NFS
高级存储：PV、PVC
配置存储：ConfigMap、Secret
```



-- 基本存储

```
EmptyDir
```

```
EmptyDir是最基础的Volume类型，一个EmptyDir就是Host上的一个空目录。

EmptyDir是在Pod被分配到Node时创建的，它的初始内容为空，并且无须指定宿主机上对应的目录文件，因为kubernetes会自动分配一个目录，当Pod销毁时， EmptyDir中的数据也会被永久删除。 EmptyDir用途如下：

临时空间，例如用于某些应用程序运行时所需的临时目录，且无须永久保留
一个容器需要从另一个容器中获取数据的目录（多容器共享目录）
接下来，通过一个容器之间文件共享的案例来使用一下EmptyDir。

在一个Pod中准备两个容器nginx和busybox，然后声明一个Volume分别挂在到两个容器的目录中，然后nginx容器负责向Volume中写日志，busybox中通过命令将日志内容读到控制台。
```

![img](k8s学习记录.assets/202307031709827.png)

创建资源文件

volume-emptydir.yaml

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: volume-emptydir
  namespace: dev
spec:
  containers:
  - name: nginx
    image: nginx:1.17.1
    ports:
    - containerPort: 80
    volumeMounts:   #将log-volume挂在到nginx容器中，对应目录 /var/log/nginx
    - name: logs-volume
      mountPath: /var/log/nginx
  - name: busybox
    image: busybox:1.30
    command: ["/bin/sh","-c","tail -f /logs/access.log"] #初始命令，动态读取指定文件中内容
    volumeMounts: # 将logs-volume 挂到busybox容器中，对应目录为 /logs
    - name: logs-volume
      mountPath: /logs
  volumes: # 声明volume, name为 logs-volume,类型为emptyDir
  - name: logs-volume
    emptyDir: {}

```



创建资源对象

```sh
kubectl create -f volume-emptydir.yaml

# 查看pod
kubectl get pods volume-emptydir -n dev -o wide

#访问PodIP
curl 10.18.189.127

# 看访问日志
kubectl logs -f volume-emptydir -n dev -c busybox
 
10.18.219.64 - - [13/Aug/2024:22:14:38 +0000] "GET / HTTP/1.1" 200 612 "-" "curl/7.61.1" "-"
容器里面要加8个小时，也就是  刚好 是 早上6：14：38，也就是我curl的时间


```

---HostPath

```
HostPath
上节课提到，EmptyDir中数据不会被持久化，它会随着Pod的结束而销毁，如果想简单的将数据持久化到主机中，可以选择HostPath。

HostPath就是将Node主机中一个实际目录挂在到Pod中，以供容器使用，这样的设计就可以保证Pod销毁了，但是数据依据可以存在于Node主机上。
```

![img](k8s学习记录.assets/202307031709059.png)

创建资源文件 volume-hostpath.yaml

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: volume-hostpath
  namespace: dev
spec:
  containers:
  - name: nginx
    image: nginx:1.17.1
    ports:
    - containerPort: 80
    volumeMounts:   #将log-volume挂在到nginx容器中，对应目录 /var/log/nginx
    - name: logs-volume
      mountPath: /var/log/nginx
  - name: busybox
    image: busybox:1.30
    command: ["/bin/sh","-c","tail -f /logs/access.log"] #初始命令，动态读取指定文件中内容
    volumeMounts: # 将logs-volume 挂到busybox容器中，对应目录为 /logs
    - name: logs-volume
      mountPath: /logs
  volumes: # 声明volume, name为 logs-volume,类型为emptyDir
  - name: logs-volume
    hostPath:
      path: /root/logs
      type: DirectoryOrCreate #目录存在就是使用，不存在就先创建再使用
```



```
关于type的值的一点说明：
    DirectoryOrCreate 目录存在就使用，不存在就先创建后使用
    Directory   目录必须存在
    FileOrCreate  文件存在就使用，不存在就先创建后使用
    File 文件必须存在 
    Socket  unix套接字必须存在
    CharDevice  字符设备必须存在
    BlockDevice 块设备必须存在
```



创建资源对象

```sh

kubectl create -f volume-hostpath.yaml
 
 #查看pod
 kubectl get pods volume-hostpath -n dev -o wide
NAME              READY   STATUS    RESTARTS   AGE   IP              NODE      NOMINATED NODE   READINESS GATES
volume-hostpath   2/2     Running   0          18s   10.18.235.162   worker1   <none>           <none>

# 访问nginx
curl 10.18.235.162

# 查看访问记录
kubectl logs -f volume-hostpath -n dev -c busybox
10.18.219.64 - - [13/Aug/2024:22:25:48 +0000] "GET / HTTP/1.1" 200 612 "-" "curl/7.61.1" "-"

# 去host的 /root/kogs目录下查看存储的文件了
## 下面操作需要到错在节点运行，这里是node1

[root@worker1 ~]# ls -lrt /root/logs
总用量 4
-rw-r--r-- 1 root root  0 8月  14 06:25 error.log
-rw-r--r-- 1 root root 93 8月  14 06:25 access.log
#  这些时间刚好是我curl的时候

# 同样道理 在这个目录创建文件，在容器中也可以看到的。
```



```
NFS
HostPath可以解决数据持久化的问题，但是一旦Node节点故障了，Pod如果转移到了别的节点，又会出现问题了，此时需要准备单独的网络存储系统，比较常用的用NFS、CIFS。

NFS是一个网络文件存储系统，可以搭建一台NFS服务器，然后将Pod中的存储直接连接到NFS系统上，这样的话，无论Pod在节点上怎么转移，只要Node跟NFS的对接没问题，数据就可以成功访问。
```

![img](k8s学习记录.assets/202307031709534.png)



```
1）首先要准备nfs的服务器，这里为了简单，直接是master节点做nfs服务器
```



```sh
# 在master上按包装nfs服务
yum install nfs-utils -y

#准备一个共享目录
mkdir /root/data/nfs -pv

#将共享目录以读写权限暴露给 192.168.93.0/24 网段中所有的主机
vim /etc/exports
# 查看写入的内容
more /etc/exports
/root/data/nfs  192.168.93.0/24(rw,no_root_squash)

#启动nfs服务
systemctl restart nfs   #这个命令不行 得有这个 systemctl restart nfs-server
Failed to restart nfs.service: Unit nfs.service not found.

#下面命令解决
systemctl status rpcbind    systemctl enable rpcbind     systemctl start rpcbind 
systemctl status nfs-server systemctl enable nfs-server  systemctl start nfs-server

#查看共享是否成功
showmount -e localhost
Export list for localhost:
/root/data/nfs 192.168.93.0/24


#在node上安装 nfs 不需要启动
yum install nfs-utils -y
  

```



创建资源文件volume-nfs.yaml

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: volume-nfs
  namespace: dev
spec:
  containers:
  - name: nginx
    image: nginx:1.17.1
    ports:
    - containerPort: 80
    volumeMounts:   #将log-volume挂在到nginx容器中，对应目录 /var/log/nginx
    - name: logs-volume
      mountPath: /var/log/nginx
  - name: busybox
    image: busybox:1.30
    command: ["/bin/sh","-c","tail -f /logs/access.log"] #初始命令，动态读取指定文件中内容
    volumeMounts: # 将logs-volume 挂到busybox容器中，对应目录为 /logs
    - name: logs-volume
      mountPath: /logs
  volumes: # 声明volume, name为 logs-volume,类型为emptyDir
  - name: logs-volume
    nfs:
      server: 192.168.93.6 #nfs服务器地址
      path: /root/data/nfs #共享文件路径

```



创建资源对象

```sh
kubectl create -f volume-nfs.yaml
pod/volume-nfs created

# 查看pod
 kubectl get pods volume-nfs -n dev
NAME         READY   STATUS    RESTARTS   AGE
volume-nfs   2/2     Running   0          16s

# 查看nfs服务器上的共享目录，发现已经有文件了
 ls -lrt /root/data

drwxr-xr-x 2 root root 41 8月  14 06:54 nfs

```



-- 高级存储

```
前面已经学习了使用NFS提供存储，此时就要求用户会搭建NFS系统，并且会在yaml配置nfs。由于kubernetes支持的存储系统有很多，要求客户全都掌握，显然不现实。为了能够屏蔽底层存储实现的细节，方便用户使用， kubernetes引入PV和PVC两种资源对象。

	PV（Persistent Volume）是持久化卷的意思，是对底层的共享存储的一种抽象。一般情况下PV由kubernetes管理员进行创建和配置，它与底层具体的共享存储技术有关，并通过插件完成与共享存储的对接。

	PVC（Persistent Volume Claim）是持久卷声明的意思，是用户对于存储需求的一种声明。换句话说，PVC其实就是用户向kubernetes系统发出的一种资源需求申请。
```

![img](k8s学习记录.assets/202307031709326.png)

```
使用了PV和PVC之后，工作可以得到进一步的细分：

存储：存储工程师维护
PV： kubernetes管理员维护
PVC：kubernetes用户维护
```

---PV

```
PV
PV是存储资源的抽象，下面是资源清单文件:
```



PV清单文件

```yaml
apiVersion: v1  
kind: PersistentVolume
metadata:
  name: pv2
spec:
  nfs: # 存储类型，与底层真正存储对应
  capacity:  # 存储能力，目前只支持存储空间的设置
    storage: 2Gi
  accessModes:  # 访问模式
  storageClassName: # 存储类别
  persistentVolumeReclaimPolicy: # 回收策略

```



```
PV 的关键配置参数说明：

存储类型

	底层实际存储的类型，kubernetes支持多种存储类型，每种存储类型的配置都有所差异

存储能力（capacity）

	目前只支持存储空间的设置( storage=1Gi )，不过未来可能会加入IOPS、吞吐量等指标的配置

访问模式（accessModes）

	用于描述用户应用对存储资源的访问权限，访问权限包括下面几种方式：

	ReadWriteOnce（RWO）：读写权限，但是只能被单个节点挂载
	ReadOnlyMany（ROX）： 只读权限，可以被多个节点挂载
	ReadWriteMany（RWX）：读写权限，可以被多个节点挂载
	需要注意的是，底层不同的存储类型可能支持的访问模式不同

回收策略（persistentVolumeReclaimPolicy）

	当PV不再被使用了之后，对其的处理方式。目前支持三种策略：

	Retain （保留） 保留数据，需要管理员手工清理数据
	Recycle（回收） 清除 PV 中的数据，效果相当于执行 rm -rf /thevolume/*
	Delete （删除） 与 PV 相连的后端存储完成 volume 的删除操作，当然这常见于云服务商的存储服务
	需要注意的是，底层不同的存储类型可能支持的回收策略不同

存储类别

	PV可以通过storageClassName参数指定一个存储类别

	具有特定类别的PV只能与请求了该类别的PVC进行绑定
	未设定类别的PV则只能与不请求任何类别的PVC进行绑定
	
状态（status）

	一个 PV 的生命周期中，可能会处于4中不同的阶段：

	Available（可用）： 表示可用状态，还未被任何 PVC 绑定
	Bound（已绑定）： 表示 PV 已经被 PVC 绑定
	Released（已释放）： 表示 PVC 被删除，但是资源还未被集群重新声明
	Failed（失败）： 表示该 PV 的自动回收失败
```



环境准备

```
使用NFS作为存储，来演示PV的使用，创建3个PV，对应NFS中的3个暴露的路径。
```



准备nfs环境

```sh
#创建3个目录
mkdir /root/data/{pv1,pv2,pv3} -pv


#暴露服务
vim /etc/exports
[root@master volume]# cat /etc/exports
/root/data/nfs  192.168.93.0/24(rw,no_root_squash)
/root/data/pv1  192.168.93.0/24(rw,no_root_squash)
/root/data/pv2  192.168.93.0/24(rw,no_root_squash)

#重启nfs
systemctl restart nfs-server
```



创建资源文件

```yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: pv1
spec:
  capacity:
    storage: 1Gi
  accessModes:
  - ReadWriteMany
  persistentVolumeReclaimPolicy: Retain
  nfs:
    path: /root/data/pv1
    server: 192.168.93.6

---

apiVersion: v1
kind: PersistentVolume
metadata:
  name: pv2
spec:
  capacity:
    storage: 2Gi
  accessModes:
  - ReadWriteMany
  persistentVolumeReclaimPolicy: Retain
  nfs:
    path: /root/data/pv2
    server: 192.168.93.6
                                                  
--- 

apiVersion: v1
kind: PersistentVolume
metadata:
  name: pv3
spec:
  capacity:
    storage: 3Gi
  accessModes:
  - ReadWriteMany
  persistentVolumeReclaimPolicy: Retain
  nfs:
    path: /root/data/pv3
    server: 192.168.93.6

```



创建资源对象

```sh
kubectl create -f pv.yaml 

kubectl get pv -n dev
NAME   CAPACITY   ACCESS MODES   RECLAIM POLICY   STATUS      CLAIM   STORAGECLASS   REASON   AGE
pv1    1Gi        RWX            Retain           Available                                   32s
pv2    2Gi        RWX            Retain           Available                                   32s
pv3    3Gi        RWX            Retain           Available                                   32s


```



---PVC

```
PVC
PVC是资源的申请，用来声明对存储空间、访问模式、存储类别需求信息。下面是资源清单文件:
```



资源清单

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: pvc
  namespace: dev
spec:
  accessModes: # 访问模式
  selector: # 采用标签对PV选择
  storageClassName: # 存储类别
  resources: # 请求空间
    requests:
      storage: 5Gi

```



```
PVC 的关键配置参数说明：

访问模式（accessModes）
	用于描述用户应用对存储资源的访问权限

选择条件（selector）

	通过Label Selector的设置，可使PVC对于系统中己存在的PV进行筛选

存储类别（storageClassName）

	PVC在定义时可以设定需要的后端存储的类别，只有设置了该class的pv才能被系统选出

资源请求（Resources ）

	描述对存储资源的请求
```



创建资源文件

pvc.yaml

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: pvc1
  namespace: dev
spec:
  accessModes:
  - ReadWriteMany
  resources:
    requests:
      storage: 1Gi
---

apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: pvc2
  namespace: dev
spec:
  accessModes:
  - ReadWriteMany
  resources:
    requests:
      storage: 1Gi
                                                  
--- 

apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: pvc3
  namespace: dev
spec:
  accessModes:
  - ReadWriteMany
  resources:
    requests:
      storage: 1Gi

```

创建pvc资源对象

```sh
kubectl create -f pvc.yaml 

# 查看pvc
kubectl get pvc -n dev -o wide

# 发现处于penging状态，查看pvc详情
kubectl describe pvc pvc1 -n dev
 Normal  FailedBinding  15s (x21 over 5m5s)  persistentvolume-controller  no persistent volumes available for this claim and no storage class is set


#这里先不管  后面再来看

```





pod --pvc--pv--{磁盘、nfs、cri、}

pv都不是真正存储的介质，最后一层才是的。就是磁盘、nfs、cri等



我们要存东西，首先创建pv,pv里面定义存储的地方。

然后再定义pvc，

最后把pvc和pod进行绑定，这个pod就是我们运行的pod，里面可以是nginx、tomcat、redis等,



这一条链路就通了，pod --pvc--pv--{磁盘、nfs、cri、}





静态构建，

动态构建，就是StorageClass来说实现的





```sh
ormal  FailedBinding  109s (x2003 over 38h)  persistentvolume-controller  no persistent volumes available for this claim and no storage class is set


kubectl delete -f pv.yaml 
在三个pv里面修改依次修改   pv1  pv2  pv3
在spec下添加  storageClassName: slow

kubectl create -f pv.yaml 

这个不能动态修改，必须先删除
在三个pvc里面依次修改  pvc1  pvc2 pvc3
# 删除
kubectl delete -f pvc.yaml 

vim  pvc.yaml 
在三个后面spec下面添加如下配置
storageClassName: slow


 kubectl create -f pvc.yaml
 
 
# 查看pv  是bound
 kubectl get pv -n dev
NAME   CAPACITY   ACCESS MODES   RECLAIM POLICY   STATUS   CLAIM      STORAGECLASS   REASON   AGE
pv1    1Gi        RWX            Retain           Bound    dev/pvc2   slow                    17s
pv2    2Gi        RWX            Retain           Bound    dev/pvc3   slow                    17s
pv3    3Gi        RWX            Retain           Bound    dev/pvc1   slow                    17s
# 查看pvc 也是bound
kubectl get pvc -n dev
NAME   STATUS   VOLUME   CAPACITY   ACCESS MODES   STORAGECLASS   AGE
pvc1   Bound    pv3      3Gi        RWX            slow           4m5s
pvc2   Bound    pv1      1Gi        RWX            slow           4m5s
pvc3   Bound    pv2      2Gi        RWX            slow           4m5s


这次该就是先删除pv  pvc    delete pv.yaml  delete pvc.yaml
然后都添加上  storageClassName: slow
在create  pv.yaml   create  pvc.yaml

最后查看  都是bound说可以使用了

```











---声明周期

```
PVC和PV是一一对应的，PV和PVC之间的相互作用遵循以下生命周期：

资源供应：管理员手动创建底层存储和PV

资源绑定：用户创建PVC，kubernetes负责根据PVC的声明去寻找PV，并绑定

	在用户定义好PVC之后，系统将根据PVC对存储资源的请求在已存在的PV中选择一个满足条件的

	一旦找到，就将该PV与用户定义的PVC进行绑定，用户的应用就可以使用这个PVC了
	如果找不到，PVC则会无限期处于Pending状态，直到等到系统管理员创建了一个符合其要求的PV
	PV一旦绑定到某个PVC上，就会被这个PVC独占，不能再与其他PVC进行绑定了

资源使用：用户可在pod中像volume一样使用pvc

	Pod使用Volume的定义，将PVC挂载到容器内的某个路径进行使用。

资源释放：用户删除pvc来释放pv

	当存储资源使用完毕后，用户可以删除PVC，与该PVC绑定的PV将会被标记为“已释放”，但还不能立刻与其他PVC进行绑定。通过之前PVC写入的数据可能还被留在存储设备上，只有在清除之后该PV才能再次使用。

资源回收：kubernetes根据pv设置的回收策略进行资源的回收

	对于PV，管理员可以设定回收策略，用于设置与之绑定的PVC释放资源之后如何处理遗留数据的问题。只有PV的存储空间完成回收，才能供新的PVC绑定和使用
```

![img](k8s学习记录.assets/202307031709521.png)



--配置存储

ConfigMap

```
ConfigMap是一种比较特殊的存储卷，它的主要作用是用来存储配置信息的。
```



创建资源文件

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: configmap
  namespace: dev
data:
  info: |
    username:admin
    password:123456

```



创建资源对象

```sh

kubectl create -f  configmap.yaml

# 查看详情
kubectl describe cm configmap -n dev

```



创建资源对象，将上面的的configmap挂载进去

pod-configmap.yaml

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: pod-configmap
  namespace: dev
spec:
  containers:
  - name: nginx
    image: nginx:1.17.1
    volumeMounts: # 将configmap挂载到目录
    - name: config
      mountPath: /configmap/config
  volumes: #引用configmap
  - name: config
    configMap:
      name: configmap
```



创建资源对象

```sh
kubectl create -f pod-configmap.yaml

查看pod
kubectl get pod pod-configmap -n dev

进入容器
kubectl exec -it pod-configmap -n dev /bin/sh



# cd /configmap/config/
# ls
info
# more info
username:admin password:123456

可以看到已经映射成功，每个configmap都映射成了一个目录
# key --->文件  value---->文件内容
 
info  文件  ///    username:admin password:123456  内容

此时如果configmap的内容更新，容器中的值也会动态更新
```



### --- Secret

```
在kubernetes中，还存在一种和ConfigMap非常类似的对象，称为Secret对象。它主要用于存储敏感信息，例如密码、秘钥、证书等等。
```

```
首先使用base64对数据进行编码
```

```sh
[root@master volume]# echo -n 'admin' | base64 
YWRtaW4=
[root@master volume]# echo -n '123456' | base64 
MTIzNDU2

```



```
接下来编写secret.yaml，并创建Secret
```

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: secret
  namespace: dev
type: Opaque
data: 
  username: YWRtaW4=
  password: MTIzNDU2
```



创建secret资源对象

```sh
kubectl create -f secret.yaml 

kubectl describe secret secret -n dev 

```

创建 pod-secret.yaml  将上面创建的secret挂载进去

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: pod-secret
  namespace: dev
spec:
  containers:
  - name: nginx
    image: nginx:1.17.1
    volumeMounts: #将secret挂载到目录
    - name: config
      mountPath: /secret/config
  volumes:
  - name: config
    secret:
      secretName: secret



```



创建资源对象

```sh
kubectl create -f pod-secret.yaml

# kubectl get pod pod-secret -n dev
NAME         READY   STATUS    RESTARTS   AGE
pod-secret   1/1     Running   0          92s

# 进入容器，已经自动解码了
[root@master volume]# kubectl exec -it pod-secret /bin/sh -n dev
kubectl exec [POD] [COMMAND] is DEPRECATED and will be removed in a future version. Use kubectl exec [POD] -- [COMMAND] instead.
# ls /secret/config/
password  username
# more /secret/config/username
admin

# more /secret/config/password
123456
```

```
至此，已经实现了利用secret实现了信息的编码。
```



查看secret

kubectl get secrets

kubectl describe secret <secret-name>

kubectl delete secret <secret-name>

 kubectl describe secret registry -n dev



## 8.安全认证





## 9.helm

包管理器

类似 npm  yum   wget  maven



helm  管理这个chart,  chart等同与镜像、等同于安装包。最后基于安装包直接装一个软件



chart:可以理解我  chart   他把 service、pod、deployment等封装起来，统一放到了一个文件里。 他都帮自己管理了，自己只需要运行就好了。 :

config： 包含了可以了合并到打包到chart的配置信息，用于创建一个可发布的对象。config是对chart的增强。

release: 理解就是一个chart的运行实例。chart是k8s里面的资源配置文件，release就是基于资源文件创建出来的资源对象。







helm客户端







helm仓库



helm安装

```ruby
`Helm`有个安装脚本可以自动拉取最新的`Helm`版本并在 本地安装。
$ curl -fsSL -o get_helm.sh https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3
$ chmod 700 get_helm.sh
$ ./get_helm.sh


#添加仓库
helm repo add bitnami https://charts.bitnami.com/bitnami
```



```sh
#查看仓库
helm repo list

Helm 自带一个强大的搜索命令，可以用来从两种来源中进行搜索：

#从 Artifact Hub 中查找并列出 helm charts。Artifact Hub中存放了大量不同的仓库。
helm search hub

#从你添加（使用 helm repo add）到本地helm 客户端中的仓库中进行查找。该命令基于本地数据进行搜索，无需连接互联网。
helm search repo 
通过执行helm search hub 命令可以找到公开可用的charts,如果不进行过滤，helm search hub 命令会展示所有可用的 charts。


helm search repo redis


helm search hub redis


CHART VERSION是chart的版本，APP VERSION是redis的版本
```



安装应用

通过命令`helm install releaseName chartName`来安装应用，`releaseName`指这次运行实例的名称，需要自己定义，`chartName`是`char`t对应的仓库名，比如上面的`bitnami/redis`是`redis`的`chartName`



releaseName chartName`  自定义实例名称   仓库chart名称

```sh
#安装redis集群
helm install redis-chart1.20.0.0 bitnami/redis-cluster 

helm install redis-server bitnami/redis --version=16.13.1
 
 
 
```



redis安装前提需要分配pvc

```sh
[root@master helm]# kubectl get pod
NAME                      READY   STATUS    RESTARTS   AGE
nginx-6799fc88d8-gs4wt    1/1     Running   0          22d
redis-server-master-0     0/1     Pending   0          3m51s
redis-server-replicas-0   0/1     Pending   0          3m51s

# kubectl describe pod redis-server-master-0

Warning  FailedScheduling  3m29s  default-scheduler  0/3 nodes are available: 3 pod has unbound immediate PersistentVolumeClaims.


he


```



由于pvc原因，导致helm安装redis没有持久目录。后面再看下pvc，之前是什么原因！！！！





redis实战2

```sh

mkdir redis
cd redis
# 先拉取下来，再修改配置。上面直接利用网络的安装，没有挂载pvc
helm  pull  bitnami/redis
#下载下来的就是helm中国的release

#解压这个release
tar -xvf  redis-20.0.2.tgz


cd redis/
[root@master redis]# ls
Chart.lock  charts  Chart.yaml  README.md  templates  values.schema.json  values.yaml


vim values.yaml  修改两处
一处 storageClass: clow
一处  persistence ： size : 1Gi


# 在redis 同级目录，  在dev空间安装
helm install redis ./redis/ -n dev

```





上面失败了，redis

需要下面的  自动

Kubernetes使用helm部署NFS Provisioner  和这个没关系 ，自己手动配置pvc的  

```
后面解决了  在nfs节点，也就是master节点执行目录赋权就好  这是pv的挂载nfs目录的文件权限

 chmod 777 /root/data/pv3   /root/data/pv2  /root/data/pv1
```



```

helm repo add nfs-subdir-external-provisioner https://kubernetes-sigs.github.io/nfs-subdir-external-provisioner/
helm repo update
helm install nfs-subdir-external-provisioner nfs-subdir-external-provisioner/nfs-subdir-external-provisioner --set nfs.server=192.168.93.6 --set nfs.path=/app/nfs/k8snfs -n nfs-provisioner --create-namespace
```



hem再次部署redis

```sh
先卸载
helm uninstall redis -n dev

再安装
helm install redis ./redis/ -n dev



```

还是不行



发现pvc没了  

立即  在helm卸载 -- > 然后 新建pvc-->  最后  在helm安装

 

发现redis的pod还是 pending

kubectl get pod -n dev



花了很多时间，就算自己弄出来了，也是碰运气，猜的，下次还是不懂，还是先去看下书吧。



```
里面有两个8Gi的地方  一个是 master。 一个是replicas的  第二个 后面改为1Gi   后面删除pv  pvc  helm  卸载redis  
再 创建pv  helm 创建 redis  

helm会创建两个pvc

kubectl get pvc -n dev
NAME                          STATUS   VOLUME   CAPACITY   ACCESS MODES   STORAGECLASS   AGE
redis-data-redis-master-0     Bound    pv1      1Gi        RWX            nfs-data       23s
redis-data-redis-replicas-0   Bound    pv2      2Gi        RWX            nfs-data       23s

```



```yaml
1.修改redis的pv size
创建的master和replica pod的默认size是8Gi，如果k8s的node没有足够的空间，会抛出如下错误：default-scheduler  0/3 nodes are available: pod has unbound immediate PersistentVolumeClaims. preemption: 0/3 nodes are available: 3 No preemption victims found for incoming pod

为此，我们可以在安装时控制以下参数重新设置pod的size，

--set replica.persistence.size=2Gi --set master.persistence.size=2Gi

--set global.storageClass=<storageclass name> (i.e., manual in this examples)

--set  replica.replicaCount=2 --set master.count=1


helm install --set replica.persistence.size=2Gi --set master.persistence.size=1Gi \
 --set global.storageClass=manual  --set  replica.replicaCount=2 --set master.count=1 linkage-redis bitnami/redis
 
 
 部署storageclass
 
 kind: StorageClass
apiVersion: storage.k8s.io/v1
metadata:
  name: manual
provisioner: kubernetes.io/no-provisioner
volumeBindingMode: WaitForFirstConsumer



PV

apiVersion: v1
kind: PersistentVolume
metadata:
  name: $pv_name
spec:
  storageClassName: manual
  capacity:
    storage: 2Gi
  accessModes:
  - ReadWriteOnce
  hostPath:
    path: $data_path  ####  这里需要赋权，问题在这里
    
    
    pv的storageClassName指向先前创建的storageclass (manual)。此外，还需要指定data的存放路径 hostPath，这要求在k8s的各node上创建该路径，并修改路径权限；
    
    chmod 777 $data_path
    
    
    否则pod会抛出如下错误: Can't open or create append-only dir appendonlydir: Permission denied
    
    
 # 自己底层是nfs,节点在master,就只在主节点使用这个赋权命令  chmod 777 /root/data/pv3   /root/data/pv2  /root/data/pv1
 
 
 等个10来分钟就好了
 
 grep -v "#" values.yaml |grep -v "^$"  去掉空格个#好开头的
 
 发现自己副本数是 3个，加上master4个了，不太对，不影响的话，先不改。


后面还是改了
replicaCount：2

后面  helm  卸载helm uninstall redis -n dev
删除 redis自动创建的pvc(自动的pvc.yaml不能创建) ， pv  （要先删除pvc,才能删除pv）
安装pv.yaml
helm 安装 redis  他会自动创建redis的pvc,根据values.yaml里面的配置，创建redis里面的pvc,然后根据storageclass匹配到自己的pv。
最后等待安装部署成功


---
helm uninstall redis -n dev  卸载不会卸载对应redishelm创建的pvc，需要下面命令手动删除。
kubectl delete pvc redis-data-redis-master-0 redis-data-redis-replicas-0 redis-data-redis-replicas-1 redis-data-redis-replicas-2 -n dev
kubectl delete -f pv.yaml
kubectl create -f pv.yaml

helm install redis ./redis/ -n dev

kubectl get po -n dev |grep redis  #  redis启动有点慢，可能要几分钟

至此helm方式部署redis已ok,后面就是如何使用了。
主要就是自己建pv,然后helm中value.yaml包下storageclass配置和pv里面一样就好

value.yaml 改动有好几个地方 副本 size:1Gi  副本数我改为1了  还有storageclass
还有就是pv挂载的nfs节点的目录 pv里面配置有连接nfs服务节点的哪些目录，最后上到这个服务节点 chmod 777 这些目录就好了。
最后helm部署redis,他会自己创建pvc去关联我的pv,创建pod节点两个，一个master\一个replicas
auth : password  :123xgz  最后还设置了密码




进入pod
kubectl exec -it redis-master-0 -n dev -- sh
或者 bash模式
kubectl exec -it redis-master-0 -n dev -- bash

redis-cli
127.0.0.1:6379> auth 123xgz
OK
127.0.0.1:6379> set name xgz
OK
127.0.0.1:6379> get name 
"xgz"
127.0.0.1:6379> 
```



helm还是需要很多东西要学的。  

看视频只有一点点内容





pv和pvc这里 还要多看看，多用几个例子。





![image-20240815070818281](k8s学习记录.assets/image-20240815070818281.png)





参考：https://znunwm.top/archives/121212

https://www.kancloud.cn/king_om/kubernetes/3154681





10.排查pod问题三板斧

就是下面的命令

kubectl logs redis-master-0 -n dev

describe

get -o wide

jouernal  这个没咋用过





## 10.k8s可视化管理UI界面

夏敏都没装过，后面有兴趣研究下。

【云原生-K8s】k8s可视化管理界面安装配置及比较【Kubesphere篇】	https://rundreams.blog.csdn.net/article/details/131029566
【云原生-K8s】k8s可视化管理界面安装配置及比较【Rancher篇】	https://rundreams.blog.csdn.net/article/details/129783273
【云原生-K8s】k8s可视化管理界面安装配置及比较【Kuboard篇】	https://rundreams.blog.csdn.net/article/details/131036281    kuboard教程https://kuboard.cn/learning/
【云原生-K8s】k8s可视化管理界面安装配置及比较【Dashboard UI篇】	https://rundreams.blog.csdn.net/article/details/129916658



### Kuboard安装

https://rundreams.blog.csdn.net/article/details/131036281



安装命令

```
kubectl apply -f https://addons.kuboard.cn/kuboard/kuboard-v3.yaml
# 您也可以使用下面的指令，唯一的区别是，该指令使用华为云的镜像仓库替代 docker hub 分发 Kuboard 所需要的镜像
# kubectl apply -f https://addons.kuboard.cn/kuboard/kuboard-v3-swr.yaml

执行命令查看是否启动成功
watch kubectl get pods -n kuboard

```





11 搭建了一个本地私有仓库

k8s读取这些仓库的镜像需要账号和密码，，必须要建立一个secret的对象来作为安全保证。



```

kubectl create secret docker-registry my-private-repo-secret \
--docker-server=<你的私有仓库地址> \
--docker-username=<你的私有仓库用户名> \
--docker-password=<你的私有仓库密码> \
--docker-email=<你的邮箱地址>


kubectl create secret docker-registry mysite-secret  -n dev  \
--docker-server=192.168.93.6:5000 \
--docker-username=xgzh \
--docker-password=123xgz \
--docker-email=626185608@qq.com


apiVersion: v1
kind: Pod
metadata:
  name: my-private-repo-pod
spec:
  containers:
  - name: my-container
    image: <私有仓库的镜像路径>
  imagePullSecrets:
  - name: my-private-repo-secret  这里##
```



```
echo '{"auths":{"docker.io": {"auth": "你的用户名和密码基础认证字符串"}}}' | base64


生成方式
echo '{"auths":{"docker.io": {"auth": "xgzh:123xgz"}}}' | base64


eyJhdXRocyI6eyJkb2NrZXIuaW8iOiB7ImF1dGgiOiAieGd6aDoxMjN4Z3oifX19Cg==




apiVersion: v1
kind: Secret
metadata:
  name: mysite2-secret
  namespace: dev
type: kubernetes.io/dockerconfigjson
data:
  .dockerconfigjson: eyJhdXRocyI6eyJkb2NrZXIuaW8iOiB7ImF1dGgiOiAieGd6aDp4Z3oxMjMifX19Cg==




kubectl create -f docker-registry-secret.yaml
```

MTIzeGd6   123xgz



注意镜像名称是

**镜像地址**    是ip+端口/镜像名称：tag

各节点  /etc/docker/daemon.json  里面添加 私人仓库地址  "insecure-registries":["http://192.168.93.6:5000"],

所有节点必须要执行   docker login 192.168.93.6:5000 -u xgzh -p 123xgz

确保所有节点都可以访问到本地镜像私有仓库。

因为这个仓库是建立在93.6节点的，其他连个节点必须要能访问才行，执行这个可以生成密码配置。





## 11.命令实战记录

 kubectl exec -it xgz-mysite-5c9bcc4dd4-qhbh4 -n dev -- /bin/sh



k8s.kuboard.cn/name=xgz-mysite

给存在的pod打标签

kubectl label pods <pod-name> <label-key>=<label-value> --namespace=<namespace>



kubectl label pods xgz-mysite-74f85b55ff-knmfp app=mysite-service --namespace=dev

查看标签

kubectl get pod xgz-mysite-74f85b55ff-knmfp -n dev -o wide --show-labels



滚动查看日志

kubectl logs -f xgz-mysite-74f85b55ff-knmfp -n dev